import requests, pandas as pd

def fetch_coingecko_btc(start="2024-01-01"):
    url = "https://api.coingecko.com/api/v3/coins/bitcoin/market_chart"
    params = {"vs_currency":"usd", "days":"max", "interval":"daily"}
    r = requests.get(url, params=params)
    data = r.json()
    dates = [pd.to_datetime(d[0], unit="ms").date() for d in data["prices"]]
    closes = [float(d[1]) for d in data["prices"]]
    df = pd.DataFrame({"date":dates, "close":closes})
    return df[df["date"] >= pd.to_datetime(start).date()]

def label_trend_every_4days(df, step=4, thresh=0.0):
    labels = []
    for i in range(len(df)):
        if i < step:
            labels.append(None)
        else:
            pct = (df.loc[df.index[i], "close"] - df.loc[df.index[i-step], "close"]) / df.loc[df.index[i-step], "close"]
            labels.append(1 if pct > thresh else (-1 if pct < -thresh else 0))
    df["trend"] = labels
    return df

df = fetch_coingecko_btc("2014-01-01")

df = label_trend_every_4days(df, step=4, thresh=0.0)
df_out = df.dropna(subset=["trend"])[["date", "trend"]]
df_out.to_csv("btc_trend_4day.csv", index=False)