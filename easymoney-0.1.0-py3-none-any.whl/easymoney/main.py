import time
import random
from collections import deque
from multiprocessing import Process, Manager, current_process
import torch.multiprocessing as mp
import json
from run.configs import Config
import pandas as pd
from multiprocessing import shared_memory
import numpy as np
import subprocess







from trade.worker import producer_task
from agent.researcher import consumer_task
from trade.bosser import validator_task
from run.dataloader import init_dadabuffer_shared

def init_dadabuffer_shared():
    """
    将多个 CSV 加载为 numpy，并写入共享内存。
    返回包含每个共享内存的信息的元数据列表。
    """
    shm_meta = []

    with open(Config.ASSETS_PATH, 'r') as file:
        datalist = json.load(file)

    for idx, filename in enumerate(datalist):
        df = pd.read_csv(f'data/result/{filename}.csv')
        df = df[Config.FEATURES]  # 只保留指定特征列
        df['timestamp'] = pd.to_datetime(df['timestamp']).astype('int64') / 1e9  # 秒为单位
        df['timestamp'] = df['timestamp'].astype(np.float32)
        if df.isna().any().any():
            print("Data contains NaN values.")
        else:
            print("No NaN values found.")

        print(f"[INIT] datalen={len(df)} | index={idx} | name={filename}")

        arr = df.astype(np.float32).to_numpy()
        shape, dtype = arr.shape, arr.dtype

        shm = shared_memory.SharedMemory(create=True, size=arr.nbytes)
        shm_arr = np.ndarray(shape, dtype=dtype, buffer=shm.buf)
        np.copyto(shm_arr, arr)

        shm_meta.append({
            "name": shm.name,
            "shape": shape,
            "dtype": str(dtype),
            "index": idx,
            "columns": df.columns.tolist()
        })

    return shm_meta

def clear_shared_memory():
    try:
        # 执行 rm /dev/shm/* 命令来清理共享内存
        subprocess.run(['rm', '-rf', '/dev/shm/*'], check=True)
        print("Shared memory cleared successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error clearing shared memory: {e}")

def main():
    mem=init_dadabuffer_shared()
    NUM_PRODUCERS =3
    #for i, df in enumerate(data):
    #    df.to_feather(f"/dev/shm/tmp_df_{i}.feather")  # `/dev/shm` 是 Linux 临时内存盘


    NUM_CONSUMERS =1
    consumer_queue = [None] * (NUM_PRODUCERS+1)  # 初始化一个长度为 NUM_PRODUCERS 的空列表





    with Manager() as manager:
        shared_meta_list = manager.list(mem)
        # 创建共享队列和事件

        producer_queue = manager.Queue()
        instrument_queue = manager.Queue(maxsize=20)
        #consumer_queue = manager.Queue(maxsize=1)
        for i in range(NUM_PRODUCERS+1):
            consumer_queue[i]= manager.Queue(maxsize=1)
        stop_event = manager.Event()

        # 创建生产者进程
        producers = [
            Process(
                target=producer_task,
                args=(producer_queue, consumer_queue[i],i, stop_event,shared_meta_list),
                name=f"Producer-{i}"
            ) for i in range(NUM_PRODUCERS)
        ]

        consumer = [
            Process(
                target=consumer_task,
                args=(producer_queue, consumer_queue,NUM_PRODUCERS, instrument_queue,i, stop_event),
                name=f"consumer-{i}"
            ) for i in range(NUM_CONSUMERS)
        ]


        # 创建验证者进程
        validator = Process(
            target=validator_task,
            args=(consumer_queue[NUM_PRODUCERS],instrument_queue, stop_event,shared_meta_list),
            name="Validator"
        )




        # 启动所有进程
        for p in producers:
            p.start()



        for p in consumer:
            p.start()

        validator.start()


        try:
            # 等待所有进程完成
            for p in producers:
                p.join()
            for p in consumer:
                p.join()
            #validator.join()
        except KeyboardInterrupt:
            print("\n🛑 接收到中断信号，停止所有进程...")
            stop_event.set()
            for p in producers:
                if p.is_alive():
                    p.terminate()
            for p in consumer:
                if p.is_alive():
                    p.terminate()

            if validator.is_alive():
                validator.terminate()


if __name__ == "__main__":
    mp.set_start_method('spawn', force=True)
    clear_shared_memory()

    main()