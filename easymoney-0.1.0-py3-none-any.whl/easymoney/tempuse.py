import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from run.configs import Config
import re
import json



def com_adv(action,options):
    advantages = torch.zeros_like(action, dtype=torch.float32)

    open_mask = (action == 1)
    open_indices = torch.where(open_mask)[0]  # 假设action=1是开仓动作
    t_open = open_indices[0].item() if len(open_indices) > 0 else -1
    t_sell = len(action) - 1

    best_open_mask = options == 1
    best_open_indices = torch.where(best_open_mask)[0]  # 假设action=1是开仓动作
    best_open = best_open_indices[0].item() if len(best_open_indices) > 0 else -1

    best_sell_mask = options == 2
    best_sell_indices = torch.where(best_sell_mask)[0]  # 假设action=1是开仓动作
    best_sell = best_sell_indices[0].item() if len(best_sell_indices) > 0 else -1

    print('t_open:',t_open)
    print('best_open:', best_open)
    print('t_sell:', t_sell)
    print('best_sell:', best_sell)

    if best_sell < best_open:
        for i in range(len(action)):
            if i == t_open or i == t_sell:
                advantages[i] = -1
            elif i < best_sell:
                advantages[i] = 1 - (i + 1) / (best_sell + 1)
            else:
                advantages[i] = -(i - best_sell) / (t_sell - best_sell)
    elif best_open > t_open and best_sell != t_sell :

        ph1 = (best_open+t_open)/2
        ph2 = (best_open-t_open)/2

        uh1 = (best_open + best_sell) / 2
        uh2 = (best_sell - best_open) / 2

        for i in range(len(action)):
            if i<= t_open:
                advantages[i] = 0.9- (i)/(t_open+1)
            elif i > t_open and i < best_open:
                advantages[i] = abs(i - ph1 )/ph2 -1.1
            elif i >= best_open and i < best_sell:
                advantages[i] = 0.9 - abs((i - uh1) / uh2)
            elif i >= best_sell :
                advantages[i] = -(i- best_sell)/(t_sell-best_sell)-0.1


        advantages[t_open]=-0.1
        advantages[t_sell] = -1.1

    elif best_open < t_open  and best_sell != t_sell:

        ph1 = (best_open + t_open) / 2
        ph2 = -(best_open - t_open) / 2
        print(f'ph1 is {ph1}  ph2 is {ph2} best_open is {best_open}  t_open is {t_open}')

        uh1 = (t_open + best_sell) / 2
        uh2 = (best_sell - t_open) / 2

        for i in range(len(action)):
            if i <= best_open:
                advantages[i] = 0.95 - (i+1 ) / (best_open + 1)
            elif i > best_open and i < t_open:
                advantages[i] =  abs((i - ph1) / ph2) -1.1
            elif i > t_open and i < best_sell:
                advantages[i] = 0.9 - abs((i - uh1) / uh2)
            elif i >= best_sell:
                advantages[i] = -(i - best_sell) / (t_sell - best_sell)-0.1

        advantages[t_open] = -0.1
        advantages[t_sell] = -1.1



    elif best_open == t_open and best_sell != t_sell:


        #ph1= (best_open + best_sell)//2
        ph2 = (best_sell - best_open)

        for i in range(len(action)):
            if i < t_open:
                advantages[i] = (i+1)/(best_open+1)
            elif i > t_open and i < best_sell:
                advantages[i] = 1- (i - best_open )/(best_sell-best_open)
            elif i>= best_sell:
                advantages[i] = -(i-best_sell)/(t_sell-best_sell)-0.1


        advantages[best_open] = 1.1
        advantages[t_sell] = -1.1
    elif best_open !=t_open and best_sell == t_sell:
        print('here')

        if best_open> t_open:
            ph1= (best_open + t_open)/2
            ph2 = (best_open - t_open)/2
            for i in range(len(action)):
                if i < t_open:
                    advantages[i] =1- (i+1)/(t_open+1)
                elif i>t_open and i < best_open:
                    advantages[i]= abs(i - ph1)/ph2 -1.1
                elif i >= best_open :
                    advantages[i]= 1+(i-best_sell)/ (t_sell-best_open) +0.1


        elif    best_open<= t_open:
            ph1 = (best_open + t_open) / 2
            ph2 = (best_open - t_open) / 2
            for i in range(len(action)):
                if i < best_open:
                    advantages[i]=0.9- (i)/(best_open+1)
                elif i >= best_open and i < t_open:
                    advantages[i] = abs((i - ph1) / ph2 )- 1.1
                elif i >=t_open:
                    advantages[i] = 1+(i - best_sell) / (best_sell - t_open) +0.1


        advantages[best_sell] = 1.1
        advantages[t_open] = -0.1

    elif best_open == t_open and best_sell == t_sell:
        ph1= (best_open + best_sell) /2
        ph2= (best_sell - best_open) /2
        for i in range(len(action)):
            if i < best_open:
                advantages[i] = i/(best_open+1)
            elif i<best_sell and i > best_open:
                advantages[i] = abs(i-ph1) / ph2

        advantages[best_open]=1.1
        advantages[best_sell] = 1.1




    return advantages


def extract_currency(input_string):
    # 使用正则表达式提取第一个货币单位
    match = re.match(r'([A-Za-z]+)', input_string)
    return match.group(1) if match else None


if __name__ == "__main__":
    file='./newtrail.csv'
    df=pd.read_csv(file)
    contr_columns = [col for col in df.columns if col.endswith('_contri')]
    #print(contr_columns)
    df_contr = df[contr_columns]
    #print(df_contr.iloc[0, :])
    #print(df_contr)
    #df=df[Config.FEATURES]
    good_act2=[]
    good_act3 = []
    bad_act2 = []
    bad_act3 = []
    good_act4 = []
    good_act5 = []
    bad_act4 = []
    bad_act5 = []
    temp=None

    profit=df['profit']
    act=df['act']
    balance=df['balance']
    profit_final=0
    last=0
    dir=0
    for i in range(len(df)):
        if act[i] in [2,3] :
            if act[i] == 2:
                temp=df_contr.iloc[i, :]
            elif act[i]==3:
                if profit[i]>0:

                    is_all_zero = all(x == 0 for x in temp)
                    if not is_all_zero:
                        good_act2.append(temp)
                    temp=df_contr.iloc[i, :]
                    is_all_zero = all(x == 0 for x in temp)
                    if not is_all_zero:
                        good_act3.append(temp)
                else:

                    is_all_zero = all(x == 0 for x in temp)
                    if not is_all_zero:
                        bad_act2.append(temp)
                    temp = df_contr.iloc[i, :]
                    is_all_zero = all(x == 0 for x in temp)
                    if not is_all_zero:
                        bad_act3.append(temp)

                temp=None

        elif act[i] in [4,5]:
            if act[i] == 4:
                temp = df_contr.iloc[i, :]
            elif act[i] == 5:
                if profit[i] > 0:

                    is_all_zero = all(x == 0 for x in temp)
                    if not is_all_zero:
                        good_act4.append(temp)
                    temp = df_contr.iloc[i, :]
                    is_all_zero = all(x == 0 for x in temp)
                    if not is_all_zero:
                        good_act5.append(temp)
                else:

                    is_all_zero = all(x == 0 for x in temp)
                    if not is_all_zero:
                        bad_act4.append(temp)
                    temp = df_contr.iloc[i, :]
                    is_all_zero = all(x == 0 for x in temp)
                    if not is_all_zero:
                        bad_act5.append(temp)

                temp = None

    good_act1_sum=sum(good_act2)+sum(good_act4)
    good_act2_sum = sum(good_act3) + sum(good_act5)
    bad_act1_sum = sum(bad_act2) + sum(bad_act4)
    bad_act2_sum = sum(bad_act3) + sum(bad_act5)

    #for i in bad_act2:
    #print(bad_act1_sum)
    print('#################')
    lengood_act2=(len(good_act3) + len(good_act5))
    lengood_act1 = (len(good_act2) + len(good_act4))
    lendbad_act2=(len(bad_act3) + len(bad_act5))
    lendbad_act1 = (len(bad_act2) + len(bad_act4))
    #print(f'lengood is {lengood} lend badd is {lendbad}')

    good_act1_mean=good_act1_sum/lengood_act1
    print(f'good1 is {good_act1_mean}')
    good_act2_mean = good_act2_sum / lengood_act2
    print(f'good2 is {good_act2_mean}')
    bad_act1_mean = bad_act1_sum / lendbad_act1
    print(f'bad1 is {bad_act1_mean}')
    bad_act2_mean = bad_act2_sum / lendbad_act2
    print(f'bad2 is {bad_act2_mean}')

    invalid_features_1 = (good_act1_mean < 0) & (bad_act1_mean > 0)
    #print(invalid_features_1)
    invalid_features_2 = (good_act2_mean < 0) & (bad_act2_mean > 0)

    invalid_feature_col_1 = np.array(contr_columns)[invalid_features_1].tolist()
    invalid_feature_col_2 = np.array(contr_columns)[invalid_features_2].tolist()

    print(f'list is {invalid_feature_col_1}  good is {good_act1_mean[invalid_features_1]} bad is {bad_act1_mean[invalid_features_1]}')
    print(f'list is {invalid_feature_col_2}  good is {good_act2_mean[invalid_features_2]} bad is {bad_act2_mean[invalid_features_2]}')

    diff = (good_act1_mean - bad_act1_mean).abs()

    # 找到最大差值的索引
    max_diff_idx = diff.argmax()

    # 输出该特征列名
    max_diff_feature_name = contr_columns[max_diff_idx]
    print("good_act1 与 bad_act1 差异最大的特征：", max_diff_feature_name)
    #print(f'final is {profit_final}')
    tb=0
    for i in range(len(df)):
        if act[i] in [3,5]:
            pro=balance[i]-10000
            tb+=pro
            
    print(tb)
    best_of=[]
    bad_of = []

    list_best= [[] for _ in range(14)]
    list_bad = [[] for _ in range(14)]
    list_best_open_long = [[] for _ in range(19)]
    list_best_open_short = [[] for _ in range(19)]
    list_best_close_long = [[] for _ in range(19)]
    list_best_close_short = [[] for _ in range(19)]
    temp=None
    t_c=None
    for i in range(len(df)):
        if act[i] in [2,4]:
            temp=df.iloc[i]
            t_c= df_contr.iloc[i, :]
            #print(temp.iloc[21])
        elif act[i] in [3,5]:
            pro =balance[i]-10000
            if pro>0:
                is_all_zero = all(x == 0 for x in t_c)
                if not is_all_zero:
                    if act[i] == 3:

                        # print(f'dagqian is {i}')
                        for x in range(19):
                            list_best_open_long[x].append(temp.iloc[x + 9])
                            list_best_close_long[x].append(df.iloc[i, x + 9])
                    elif act[i] == 5:
                        for x in range(19):
                            # print(x)
                            list_best_open_short[x].append(temp.iloc[x + 9])
                            list_best_close_short[x].append(df.iloc[i, x + 9])






                print(f'good factor is {temp[27]}')
                print(f'goodi is {temp[12]}')
                for x in range(14):
                    #print(x)
                    list_best[x].append(abs(temp.iloc[x+9]))

            else:





                print(f'bad factor is {temp[27]}')
                print(f'badi is {temp[12]}')
                for x in range(14):
                    list_bad[x].append(abs(temp.iloc[x+9]))
            temp=None
            t_c=None

    for i in range(14):
        tmp1=np.mean(list_best[i])

        tmp2 = np.mean(list_bad[i])
        if tmp1>=tmp2:
            print(f'find good i is {i} 1 is {tmp1} 2 is tmp2 {tmp2} radio is {tmp1/tmp2}')

    print(list_best[0])

    print('3333多空有效特征')

    for i in range (19):
        good_open_long=np.mean(list_best_open_long[i])
        good_open_short = np.mean(list_best_open_short[i])
        good_close_long = np.mean(list_best_close_long[i])
        good_close_short = np.mean(list_best_close_short[i])
        print(f' index {df.columns[i+9]} 开多 {good_open_long} 开空 {good_open_short} 平多 {good_close_long}  平空 {good_close_short}' )
        if i+9 ==13:
            print(list_best_open_long[i])
















