
import pandas as pd
import csv
from trade.traj import TrajManage


from run.configs import Config
from trade.env import TradingEnv
import numpy as np
#from tft_model_position import DoubleTunelTransformer
from agent.ppo_agent import PPOAgent

import torch

from tqdm import tqdm
from trade.profit_record import record_manager
import json
from run.dataloader import get_satart


class model_backtester:
    def __init__(self,PATH=Config.BEST_MODEL_PATH):
        self.asset_list = self.init_assetlist()
        self.path=PATH
        self.device = self.get_device()
        self.agent=PPOAgent(4,1)
        self.agent.model.to(self.device)
        #self.ckeck_len=5*Config.PPO_STEPS
        self.ckeck_len = 10000
        self.env_list = self.init_env()
        self.best_profit = []
        self.env=None
        self.trail=[]
        self.loggerpath="newtrail.csv"

        #self.close_logger()
    def init_assetlist(self):
        with open(Config.ASSETS_PATH, 'r') as file:
            content = file.read()
            datalist = json.loads(content)
            return datalist
        return None
    def init_env(self):
        env_list=[]
        for x in range(len(self.asset_list)):

            df = pd.read_csv(f'data/result/{self.asset_list[x]}.csv')
            #print(f'begin boss')
            df = df[Config.FEATURES]
            len_d = int(len(df) * 0.2)
            df = df.tail(len_d)
            env_t=TradingEnv(df)
            env_list.append(env_t)

        return env_list

    def chose_new_trade(self):
        env_num =  np.random.randint(0, len(Config.ASSET))
        self.now_env=env_num
        self.env=self.env_list[env_num]
        self.env.reset()
        check_len = self.env.n_step - Config.PPO_STEPS -Config.WINDOW_SIZE -2
        #start=  np.random.randint(1, check_len)
        start=get_satart(self.env.n_step,0.9,1)

        self.env.current_step=start+Config.WINDOW_SIZE
        start_data= self.env.features[start+1:self.env.current_step+1]
        start_data=start_data[:, 6:]

        start_data[:, -5:] = 0.0
        return start_data





    def trail_logger(self,log,state,contrib,logit,reward):
        #print(f'raw is {raw}')
        #print(f'indicater is {indicater}')
        series = pd.Series(state)
        log_s= pd.Series(log)
        #print(f'con tri s {contrib}')

        contrib_s=pd.Series(contrib.cpu().detach().numpy().flatten())
        logit_s=pd.Series(logit.cpu().detach().numpy().flatten())
        series_reward = pd.Series(reward)



        cominde1=pd.concat([log_s,series,contrib_s,logit_s,series_reward], ignore_index=True)

        #print(f'comined one {cominde1}')
        #print(f'state is {state}')
        self.trail.append(cominde1)



    def close_logger(self):
        #print(f'raw is {raw}')
        #print(f'indicater is {indicater}')
        col_1=Config.FEATURES

        col2_contri=[]
        col_2= Config.FEATURES[7:]
        for i in col_2:
            temp=i+"_contri"
            col2_contri.append(temp)
        state=['pos','profit','dur','position_size']
        for i in state:
            col2_contri.append(i)




        #print(col_2)
        col_3= list(self.env.pos_state.keys())
        col_4="empty,hold,open_long,more_long,less_long,close_long,open_short,more_short,less_short,close_short,reward"
        col_4_list = col_4.split(',')
        col=col_1+col_3+col2_contri+col_4_list

        with open(self.loggerpath, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(col)
            writer.writerows(self.trail)  # 写入多行数据

    def get_device(self):
        #device_id = random.choice([0, 1])  # 假设你有两个GPU

        device_id=0

        torch.cuda.set_device(device_id)  # 设置当前进程使用的GPU
        device = torch.device(f'cuda:{device_id}' if torch.cuda.is_available() else 'cpu')
        return device




    def check_work(self,list,record):

        win,yingkui=record.print_record()
        radio=np.mean(self.best_profit)*win
        print(f'best is {radio},final is {win*radio}')
        self.best_profit = []

        #profit, good_count, bad_count, radio = self.env.profit.getprofit()




        #print(f'prorit radio is{radio_show} good is {good_count} bad is {bad_count}')

        #self.env.reward.print_metrics()


    def get_model(self):
        self.agent.load_model(self.path)
        self.agent.model=self.agent.model.to(self.device)
        self.agent.model.train()



        return

def validator_task():
    boss = model_backtester()
    profit_record = record_manager()
    #boss.env.dist_max = True

    max_collect=boss.ckeck_len
    collect_data = 0
    boss.get_model()
    reward_list = []
    action_list = []
    protio_list = []
    done = False
    with tqdm(total=max_collect, desc=f"backtest check work round {boss.path}") as pbar:
        while not (collect_data > max_collect and done == True):
            data = boss.chose_new_trade()
            #boss.close_logger()
            done = False
            step = 0
            open = 0
            mem = TrajManage()

            while done != True:
                #if boss.env.position==1:
                #    print(f"raw data is  is {data[-1]}")
                data_t = boss.agent.model.create_input_dict(data,boss.device)


                boss.agent.model.get_contribu = True

                logit,values,contrib,dir=boss.agent.model(data_t)
                #if boss.env.position == 1:
                #print(f"contr is {contrib}")


                #logit = logit

                #max_index=logit.argmax()


                action=boss.env.dist_env(logit)
                index=boss.env.current_step
                log_data=boss.env.features[index]
                #boss.env.df.iloc[index, -5]
                next_state, reward, done, real_act, price= boss.env.step(action)
                mem.process_data(reward, real_act, None, done, values.clone().cpu(), price,
                                 logit.squeeze(0)[action].clone().cpu())

                if real_act != action:

                    contrib=0*contrib

                if real_act == 2:
                    open = step
                    # pp=price
                    profit_record.add_new_record(price, 0, boss.env, step, 1)
                elif real_act == 6:
                    # pp=price
                    open = step
                    profit_record.add_new_record(price, 0, boss.env, step, -1)
                elif done == True:
                    hold = step - open
                    profit_record.close_record(price, hold, boss.env.balance - Config.INITIAL_BALANCE)

                if done == True:
                    if mem.best_radio > 0:
                        boss.best_profit.append(mem.best_radio)
                    mem.clear_memory()
                    mem = None
                    # print(f'')

                #print(reward)
                #reward=reward
                log_state=boss.env.pos_state
                reward_list.append(reward)
                action_list.append(boss.env.open_factor)
                protio_list.append(boss.env.current_portfolio)


                boss.trail_logger(log_data,log_state,contrib,logit,reward)
                del logit, data_t


                data = next_state

                collect_data+=1
                pbar.update(1)
                step += 1
                #交互循环结束

        data = {
            'reward': reward_list,
            'action': action_list,
            'portfolio': protio_list  # 如果是字典/对象需要特殊处理
        }

        df = pd.DataFrame(data)
        df.to_csv('check_test_log.csv', index=False)
        boss.check_work(reward_list,profit_record)
        boss.close_logger()


if __name__ == "__main__":
    validator_task()