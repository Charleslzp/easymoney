from easymoney.agent.ppo_agent import PPOAgent
from easymoney.data.feature import FeatureEngine
from easymoney.trade.env import TradingEnv
from easymoney.run.configs import Config
import torch
import pandas as pd
import os


class PPPO_Connector():

    def __init__(self, name='defqlut', long_model=None, short_model=None, trend_csv=None, agent=None, id=0):
        self.name = name
        self.id = id
        self.device = self._get_device()

        self.longagent = long_model
        self.shortagent = short_model

        # 判断是使用 trend_csv 还是手动传入方向
        self.trend_csv = trend_csv
        self.use_trend_file = trend_csv is not None

        if long_model != None and short_model != None:
            print(f'model is exist')
            self.longagent.model.to(self.device)
            self.long_modle = self.longagent.model
            self.long_modle.eval()
            self.shortagent.model.to(self.device)
            self.short_modle = self.shortagent.model
            self.short_modle.eval()
        else:
            print(f'model is not exist')
            self.agent = None

        self.ft = FeatureEngine()
        self.env = TradingEnv(type='stream')
        self.ready_towork = False
        self.init_state = False
        self.action = 0
        self.reward = 0
        self.vol_factor = 0
        self.volume = 0

    def get_recnet_dir(self):
        """从 trend_csv 文件读取最新方向"""
        if not self.use_trend_file:
            raise ValueError("trend_csv is None, cannot read direction from file")

        data = pd.read_csv(self.trend_csv, parse_dates=["timestamp"])
        latest_row = data.loc[data["timestamp"].idxmax()]
        latest_date = latest_row["timestamp"].date()
        latest_trend = latest_row["trend"]
        return latest_trend

    def _get_device(self):
        DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
        return DEVICE

    def _add_data(self, data):
        df = self.ft.process(data)
        if df is not None:
            self.env.add_data(df)

    def init(self, data):
        x = 0
        for i, row in data.iterrows():
            x += 1
            ret = self.ft.process(row)
            if ret is not None:
                ret["asset"] = self.id
                self.env.add_data(ret)

        if len(self.env.features) == Config.WINDOW_SIZE:
            self.ready_towork = True

        if self.ready_towork == True:
            self.init_state = True
            print('init ok')

        return self.init_state

    def _get_recent(self):
        data = self.env._get_observation()
        return data

    def _step(self, state):
        data_t = self.agent.model.create_input_dict(state, self.device)
        with torch.no_grad():
            logit, values, vol = self.agent.model(data_t)

        self.agent.model.debug = False

        is_force, action = self.env.dist_env(logit)
        reward, done, action, current_price = self.env.step(action, vol.item())
        if action == 4:
            self.env.reset()

        return action, reward, vol.item()

    def work(self, data, dir=None):
        """
        执行交易决策

        参数:
            data: 市场数据
            dir: 交易方向 (可选)
                - 如果 trend_csv 不为 None，则忽略此参数，从文件读取方向
                - 如果 trend_csv 为 None，则必须传入 dir 参数 (1=做多, -1=做空)

        返回:
            action: 交易动作
            direction: 使用的方向
            vol: 交易量
        """
        self._add_data(data)

        if self.init_state == True:
            data = self._get_recent()

            # 确定交易方向
            if self.use_trend_file:
                # 使用 trend_csv 文件
                direction = self.get_recnet_dir()
            else:
                # 使用传入的 dir 参数
                if dir is None:
                    raise ValueError("dir parameter is required when trend_csv is None")
                direction = dir

            # 根据持仓情况设置方向
            if self.env.position == 0:
                self.env.dir = direction

            # 根据方向选择代理
            if self.env.dir == 1:
                self.agent = self.longagent
            else:
                self.agent = self.shortagent

            action, reward, vol = self._step(data)
            self.action = action
            self.reward = reward
        else:
            print(f'not init')
            action = None
            direction = None
            vol = 0

        return action, self.env.dir, vol


if __name__ == "__main__":
    agent = PPOAgent(4, 1, 'cpu')
    long_path = Config.LONG_PATH_DR
    short_path = Config.SHORT_PATH_DR

    # 示例1: 使用 trend_csv 文件
    print("=" * 50)
    print("示例1: 使用 trend_csv 文件")
    print("=" * 50)
    trend_csv = "data/trend_raw.csv"
    longagent = PPOAgent(4, 1, 'cpu')
    shortagent = PPOAgent(4, 1, 'cpu')
    longagent.load_model(long_path)
    shortagent.load_model(short_path)

    pc1 = PPPO_Connector(name='BTC', long_model=longagent, short_model=shortagent,
                         trend_csv=trend_csv, agent=agent, id=0)

    input_data = pd.read_csv("./data/result/BTC.csv")
    input_data = input_data.tail(6000)
    len_data = 3000
    initdata = input_data[:len_data]
    workdata = input_data[len_data:]

    init_re = pc1.init(initdata)
    if init_re == True:
        print(f'init ok')
        for index, row in workdata.iterrows():
            action, direction, vol = pc1.work(row)  # 不传入 dir
            if action != None:
                print(f'action: {action}, dir: {direction}, index: {index}')

    # 示例2: 手动传入方向
    print("\n" + "=" * 50)
    print("示例2: 手动传入方向")
    print("=" * 50)
    longagent2 = PPOAgent(4, 1, 'cpu')
    shortagent2 = PPOAgent(4, 1, 'cpu')
    longagent2.load_model(long_path)
    shortagent2.load_model(short_path)

    pc2 = PPPO_Connector(name='BTC', long_model=longagent2, short_model=shortagent2,
                         trend_csv=None, agent=agent, id=0)  # trend_csv=None

    init_re2 = pc2.init(initdata)
    if init_re2 == True:
        print(f'init ok')
        for index, row in workdata.iterrows():
            # 手动决定方向，例如根据某些条件
            manual_dir = 1 if index % 2 == 0 else -1  # 示例逻辑
            action, direction, vol = pc2.work(row, dir=manual_dir)  # 传入 dir
            if action != None:
                print(f'action: {action}, dir: {direction}, index: {index}')

    print(f'\nend sim')