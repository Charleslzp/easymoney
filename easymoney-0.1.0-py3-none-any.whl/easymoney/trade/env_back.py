from collections import deque
from collections import deque

import gym
from gym import spaces
import numpy as np
import math
from easymoney.run.configs import Config
import pandas as pd
import os
import time
import torch

class Profit:
    def __init__(self):
        self.profit=0
        self.profit_count=0
        self.profit_good=0
        self.profit_bad=0
        self.profit_start=0
        self.profit_end=0
        self.emptylist=[]
        self.holdinglist=[]
        self.profit_list_good=[]
        self.profit_list_bad = []
        self.stop_loss = 0


    def reset(self):
        self.profit = 0
        self.profit_count = 0
        self.profit_good = 0
        self.profit_bad = 0
        self.profit_start = 0
        self.profit_end = 0
        self.emptylist = []
        self.holdinglist = []
        self.profit_list_good = []
        self.profit_list_bad = []
        self.stop_loss=0

    def countgood(self,profit,step):
        self.profit +=profit
        self.profit_good+=1
        self.count_holdlist(step)
        self.profit_list_good.append(profit)


    def countbad(self,profit,step):
        self.profit +=profit
        self.profit_bad+=1
        self.count_holdlist(step)
        self.profit_list_bad.append(profit)

    def count_emptylist(self,empty):
        self.emptylist.append(empty)
    def count_holdlist(self,hold):
        self.holdinglist.append(hold)
    def getprofit(self):
        win_len=len(self.profit_list_good)
        win_sum=sum(self.profit_list_good)
        loss_len=len(self.profit_list_bad)
        loss_sum=sum(self.profit_list_bad)
        print('交易信息：')
        print(f'总交易({win_len+loss_len})笔，总利润：{(win_sum+loss_sum):4f},盈利({win_len})笔，利润:{(win_sum):4f},亏损({loss_len})笔，亏损:{(loss_sum):4f},强平({self.stop_loss})笔')
        print(f'最大利润:{max((self.profit_list_good)):4f}，最大亏损{min(self.profit_list_bad):4f}，胜率:{(win_len/(win_len+loss_len + 1e-9)):4f}')
        print(f'平均持仓时间:{sum(self.holdinglist)/(len(self.holdinglist)+1e-9):2f}，最大持仓时间:{max(self.holdinglist)}，最小持仓时间{min(self.holdinglist)}')
        print(f'平均空仓时间:{sum(self.emptylist)/(len(self.emptylist)+1e-9):2f}，最大空仓时间:{max(self.emptylist)}，最小空仓时间:{min(self.emptylist)}')


        self.reset()
        return

class TradingEnv(gym.Env):
    """
    改进版本交易环境：
    1. 基于价格的动态止损机制
    2. 科学的仓位规模计算
    3. 合理的手续费扣除逻辑
    4. 收益计算标准化
    5. 特征标准化处理

    df 需要包含:
    - "high", "low" (止损判断用)
    - "atr_14" (ATR 指标)
    - 以及 Config.FEATURES 中的列

    df_close 可以包含 ["timestamp", "close", "high", "low"] 等你需要的价格信息
    """

    def __init__(self, df=None,type="file"):
        super(TradingEnv, self).__init__()

        self.balance = Config.INITIAL_BALANCE  # 关键：余额重置
        self.portfolio_values = [self.balance]
        self.max_portfolio = self.balance
        self.current_portfolio = self.balance
        self.position = 0
        self.position_size = 0.0
        self.position_u = 0.0
        self.entry_price = 0.0
        self.last_portfolio = 0
        self.last_best_portfolio = 0
        self.current_portfolio = 0
        self.holding_time = 0
        self.trade_records_good = []  # 使用数组记录交易信息
        self.trade_records_bad = []  # 使用数组记录交易信息
        self.empty_entry = 0
        self.open_factor = 0
        self.pricelist=[]
        self.position_times=0
        self.cooldown=0

        self.last_best_price = 0
        self.empty_time = 0
        self.err_0 = 0
        self.err_1 = 0
        self.err_2 = 0
        self.err_3 = 0
        self.happy_holding = 0
        self.break_time = 0
        self.down = False

        self.last_position = 0
        self.last_best_buy = 0
        self.last_best_sell = 0

        self.back_test = {
            "position": self.position,
            "act": 0,
            "profit": 0,
            "stoploss": 0,
            "balance": self.balance
        }

        self.best_buy_pos = 0
        self.best_sell_pos = 0
        self.best_step_count = 0
        self.best_min = 0
        self.best_values = 0
        self.best_count = 0
        self.last_profit_values = 0


        # 初始化数据（不包含状态变量）
        self.type = type


        if type=="file":
            #self.df = df.reset_index(drop=True)
            #self.df_close = df_close.reset_index(drop=True)

            self.features = df.values

            self.prices = self.features[:,3]
            self.highs = self.features[:,1]
            self.lows = self.features[:,2]
            #self.sar_b = self.df_close["SAR_break"].values
            #self.macd_b = self.df_close["MACD_break"]

            #self.atr_values = self.df_close["atr_14"].values
            self.n_step = len(self.features)
        else:
            self.features=deque(maxlen=Config.WINDOW_SIZE)
            self.price=0
            self.n_step=0
            self.df_close=deque(maxlen=Config.WINDOW_SIZE)

        self.entry_price=0
        self.window_size = Config.WINDOW_SIZE
        self.dist_max=False



        self.holding_time = 0
        self.position_u = 0.0
        self.trade_records_good = []  # 使用数组记录交易信息
        self.trade_records_bad = []  # 使用数组记录交易信息

        self.last_portfolio=0
        self.last_best_portfolio=0
        self.last_best_price=0
        #prft=Profit()
        #self.profit =prft
        self.current_portfolio=0
        self.empty_time=0
        self.err_0=0
        self.err_1 = 0
        self.err_2= 0
        self.err_3 = 0
        self.happy_holding=0
        self.break_time=0
        self.down=False
        #self.action_quean=deque(maxlen=10)
        self.postion_init = False

        self.last_position=0
        self.len_control=False
        self.empty_entry=0
        self.last_profit_values=0
        self.last_best_buy=0
        self.last_best_sell=0
        self.begin=0
        self.last=0
        self.last_state=[0]*5







        # 初始重置
        if type=="file":
            self.current_step = self.window_size+1

    def add_data(self,df):
        tempdata=[0]*len(Config.FEATURES)
        index=0
        for i in Config.FEATURES:
            #print(f'x is {index} i is {i}')
            tempdata[index]=df[i]
            index+=1

        tempdata[-5]=self.last_state[-5]
        tempdata[-4] = self.last_state[-4]
        tempdata[-3] = self.last_state[-3]
        tempdata[-2] = self.last_state[-2]
        tempdata[-1] = self.last_state[-1]


        #print(tempdata)
        self.features.append(tempdata)
        #print(f'dflcose {df_close} , 0 is {df_close[1]}')

        self.price = df["close"]
        self.n_step+=1




    def reset(self):
        """完全重置所有状态到初始值"""
        self.current_step = min(self.window_size-1, self.n_step - 1)  # 防止越界

        self.balance = Config.INITIAL_BALANCE  # 关键：余额重置
        self.portfolio_values = [self.balance]
        self.max_portfolio = self.balance
        self.current_portfolio = self.balance
        self.position = 0
        self.position_size = 0.0
        self.position_u = 0.0
        self.entry_price = 0.0
        self.last_portfolio = 0
        self.last_best_portfolio = 0
        self.current_portfolio=0
        self.holding_time = 0
        self.trade_records_good = []  # 使用数组记录交易信息
        self.trade_records_bad = []  # 使用数组记录交易信息
        self.empty_entry = 0
        self.open_factor=0
        self.begin = 0
        self.last = 0

        self.last_best_price = 0
        self.empty_time = 0
        self.err_0 = 0
        self.err_1 = 0
        self.err_2 = 0
        self.err_3 = 0
        self.happy_holding = 0
        self.break_time = 0
        self.down = False

        self.last_position=0
        self.last_best_buy = 0
        self.last_best_sell = 0



        self.back_test={
            "position":self.position,
            "act":0,
            "profit":0,
            "stoploss":0,
            "openfacter":0,
            "balance":self.balance
        }

        self.best_buy_pos=0
        self.best_sell_pos=0
        self.best_step_count=0
        self.best_min=0
        self.best_values=0
        self.best_count=0
        self.last_profit_values=0




    def rest_best(self):
        self.best_buy_pos = 0
        self.best_sell_pos = 0
        self.best_step_count = 0
        self.best_min = 0
        self.best_values = 0
        self.best_count = 0

    def caluclate_reward(self,action,price,macd):
        reward=0

        profit=self.cal_profit(price)
        if action == 2:

            reward = profit



            if reward>0.02:
                reward*=10
            elif reward<-0.01 :
                reward*=8
            else:
                reward*=8
            if self.last_best_sell != 0 :
                adj = -(self.last_best_sell - price) / self.last_best_sell * 10
                self.last_best_sell = 0
                #reward += adj

            if self.holding_time<3:
                reward+=-0.2
            elif self.holding_time>200:
                reward += -0.2


            #self.last_profit_values=macd
        elif action == 1:
            reward = profit

            if reward>0.02:
                reward*=10
            elif reward<-0.01 :
                reward*=8
            else:
                reward*=8

            if self.last_best_buy !=0:
                adj =  (self.last_best_buy - price)/self.last_best_buy * 10
                self.last_best_buy=0
                #reward += adj

            if self.empty_time < 3:
                reward += -0.2
            elif self.empty_time > 200:
                reward += -0.2
            #self.last_profit_values=macd

        elif action == 3:
            if self.last_profit_values!=0:
                reward = (macd - self.last_profit_values)/30

            if self.last_best_sell == 0:
                self.last_best_sell=price
            elif price >self.last_best_sell:
                self.last_best_sell = price

            reward=0

        elif action ==0:
            reward=0

            if self.last_best_buy==0:
                self.last_best_buy = price
            elif price < self.last_best_buy:
                   self.last_best_buy = price

            if self.last_profit_values != 0:
                reward += -(macd - self.last_profit_values)/30

            reward = 0

        if action not in [1,2]:
            self.last_profit_values=macd



        return reward

    def get_dir(self,pricelist):
        max_index=0
        max_value=pricelist[0]
        min_value=pricelist[0]
        min_index=0
        for i in range(len(pricelist)):
            if pricelist[i]>=max_value:
                max_index=i
                max_value=pricelist[i]
            elif pricelist[i]<=min_value:
                min_index=i
                min_value = pricelist[i]
        if max_index>min_index:
            return 1
        else:
            return -1

    def dist_env(self, logit, ):

        logit = logit.squeeze(0)
        dir=logit[0].item()
        act = logit[1].item()

        max_empty=30
        max_hold=10
        ret=0

        if self.empty_time>=max_empty:
            ret = np.random.randint(0,2)
            return ret
        elif self.holding_time>max_hold:
            ret=3
            return ret

        if abs(dir)>0.1 :
            if act > 0.5 and self.cooldown>=2:
                return 1
            elif act < -0.5 and  self.cooldown>=2:
                return 2
            elif np.sign(dir) != self.position and self.position_times>0:
                return 3















    def _get_observation(self):
        """获取 (window_size, feature_dim) 的特征窗口"""
        start_idx = max(0, self.current_step - self.window_size+1 )
        end_idx = self.current_step+1

        #ret = pd.DataFrame(self.features)

        obs=self.features[start_idx:end_idx,6:]
        #with pd.option_context('display.max_rows', None,
        #                       'display.max_columns', None,
        #                       'display.width', 1000,
        #                       'display.max_colwidth', 20):
        #    print(obs.tail(10))
        #print()

        #print(f"obs pos is {obs["position"].iloc[-1]} curstep is {self.current_step}")

        return obs

    def _calculate_position_size(self, current_atr):
        """根据市场波动和最大仓位限制计算仓位"""
        base = 5
        if self.type == "file":
            fe1=self.features[self.current_step,13]
        else:
            last = self.features[-1]
            fe1=last[13]
        #fe2 = self.features[self.current_step, 12]
        #fe3 = self.features[self.current_step, 13]



        #final=abs(fe1)+abs(fe2)+abs(fe3)

        str=abs(fe1)
        final=str

        if final == 0:
            final=0.1


        #final=1

        self.open_factor=final


        #print(self.open_factor)




        return Config.TRANSACTION_PER * final

    def _check_stop(self, price):
        need_stop_win=True
        """动态止损检查: 根据当前市场波动动态调整止损"""
        #profit_base = (self.get_value(current_atr)-self.last_portfolio) / Config.TRANSACTION_PER
        if self.position==1:
            profit_base= (price - self.entry_price)/(self.entry_price+1e-9) - 2*Config.TRANSACTION_FEE
        elif self.position==-1:
            profit_base = -(price - self.entry_price) / (self.entry_price + 1e-9) - 2 * Config.TRANSACTION_FEE
            #profit_base=-profit_base
        else:
            return False
        min=0.001
        if self.open_factor>1:
            profit=profit_base*self.open_factor//min
        else:
            profit = profit_base// min

        if self.position !=0 and profit <=0 :
            if abs(profit) > Config.RISK_STOP_LOSS:

                #print(f'profit_base is {profit} price is {price} entry si {self.entry_price}')

                return True
        elif need_stop_win==True and self.position !=0 and profit >0:
            if self.open_factor==0:
                print(f'big error self.openfcoter is 0 pos is {self.position}  empty is {self.empty_time} hold is {self.holding_time}')

            if abs(profit)/self.open_factor > Config.RISK_STOP_WIN:
                return True

        else:
            return False


    def _check_stop_win(self, price):
        """动态止损检查: 根据当前市场波动动态调整止损"""
        #profit_base = (self.get_value(current_atr)-self.last_portfolio) / Config.TRANSACTION_PER
        if self.position==1:
            profit_base = (price - self.entry_price) / (self.entry_price + 1e-9) - 2 * Config.TRANSACTION_FEE
        elif self.position==-1:
            profit_base = -(price - self.entry_price) / (self.entry_price + 1e-9) - 2 * Config.TRANSACTION_FEE
        else:
            return False

        min=0.001
        profit=profit_base//min

        if self.position != 0 and  profit * self.open_factor > Config.RISK_STOP_WIN:

            #print(f'profit_base is {profit} price is {price} entry si {self.entry_price}')

            return True

        return False

    def _close_position(self, current_price,stop_loss):
        """平仓通用逻辑: 计算盈亏 + 扣手续费"""
        if self.position == 1:  # 多头仓位
            pnl = self.position_size * (current_price - self.entry_price)  # 计算盈亏
        else:  # 空头仓位
            pnl = self.position_size * (self.entry_price - current_price)  # 计算盈亏

        # 手续费计算 (以当前价格乘以仓位的 BTC 数量)
        fee = self.position_size * current_price * Config.TRANSACTION_FEE

        # 计算净盈亏
        net_pnl = pnl - fee

        # 更新账户余额，余额增加盈亏和扣除手续费后的净额
        self.balance += net_pnl + self.position_u

        # 记录交易信息


            #print(f'🟣 close wrong at price {current_price} balance is {self.balance} entry price is {self.entry_price} net_pnl is {net_pnl}')

        # 清空仓位
        self.position = 0
        self.position_size = 0.0
        self.position_u=0.0
        self.entry_price = 0.0
        self.last_portfolio=self.balance
        self.empty_entry=current_price


        return net_pnl


    def update_position(self,profit,action,cur_dur,las_dur,openfacter):

        line_index=self.current_step+1
        if line_index >= self.n_step:
            return None

        if self.type=="stream":
            last=self.features[-1]

            last[ -5] = self.position
            last[ -4] = profit
            last[ -3] = action
            last[ -2] =  cur_dur
            last[-1] = las_dur

            self.last_state[-5]=self.position
            self.last_state[-4] = profit
            self.last_state[-3] = action
            self.last_state[-2] = cur_dur
            self.last_state[-1] = las_dur

        else:

            self.features[line_index,-5]=self.position
            self.features[line_index,-4] = profit
            self.features[line_index,-3] = action
            self.features[line_index,-2] = cur_dur
            self.features[line_index,-1] = las_dur





    def get_mask(self):
        if self.position==0:
            return Config.VALID_ACTIONS[1]
        else :
            return Config.VALID_ACTIONS[0]

    def update_state(self, act, record, stoploss,openfacter
                     ):

        if record == 1:
            if act == 2:
                self.empty_time = 0
                self.holding_time = 0
                self.position = 1
                self.empty_entry = 0
            elif act == 4:
                self.empty_time = 0
                self.holding_time = 0
                self.position = -1
                self.empty_entry = 0
            elif act == 3 or act == 5:
                self.empty_time = 0
                self.holding_time = 0
                self.position = 0
                self.entry_price = 0
            else:
                print(f'st is wrong')

        else:
            # print(f'update state error1 action is {act}  position is {self.position}')
            if self.position == 0:
                self.empty_time += 1
            else:
                self.holding_time += 1

        # print(f'emtpy is {self.empty_time} hold is {self.holding_time}')

        self.back_test['position'] = self.position
        self.back_test['act'] = act
        self.back_test['openfacter']=openfacter

        self.back_test['profit'] = self.profit_value
        self.back_test['stoploss'] = stoploss
        self.back_test['balance'] = self.current_portfolio

        return act

    def cal_profit(self,current_price):
        factor=0.1/200

        if self.position == 0:
            if self.empty_entry == 0:
                self.empty_entry = current_price
                profit=0
            else:
                profit = self.empty_entry / current_price - 2 * Config.TRANSACTION_FEE - 1
            timefactor = self.empty_time /5000

            profit=0


        else:
            if self.position==1:
                profit = current_price / self.entry_price - 2 * Config.TRANSACTION_FEE - 1
            if self.position==-1:
                profit = -current_price / self.entry_price - 2 * Config.TRANSACTION_FEE + 1

            timefactor = self.holding_time / 5000

        timefactor=0
        timefactor=min(1, timefactor)
        if profit<0.004 and profit>0:
            profit=-0.001


        self.profit_value=(profit -timefactor*abs(profit))


        return  self.profit_value



    def step(self, action,logit=None,pos=-9):
        """执行环境步进逻辑"""
        done = False
        time1=time.time()
        reward=0
        record=0
        if self.type=="file":
            current_price = self.prices[self.current_step]


            current_atr = self.features[self.current_step,14]

            #print(f'current_price is {current_price}')
        else:
            current_price=self.price
            self.current_step=-1
            last_element = self.features[-1]

            current_atr = last_element[14]

        if self.begin==0:
            self.begin=current_price
        self.last = current_price
        self.pricelist.append(current_price)

        if self.position!=0 and self.open_factor ==0:
            print(f'error in step act is {action}')
        # 先检查是否触发止损
        stop_triggered = self._check_stop(current_price)
        #check_win_triggered=self._check_stop_win(current_price)

        if stop_triggered :
            #action=4
            #reward = 4
            if self.position==1:
                action=3
            elif self.position==-1:
                action=5


            reward1 = self.caluclate_reward(action, current_price,current_atr)
            # 平仓
            #print(f'qiangping  entry price {self.entry_price} now price {current_price}')
            self._close_position(current_price,True)

            record=1

        else:
            #if  check_win != True and action ==2 and current_price > self.entry_price and self.holding_time < 200 and self.position==1:
            #    action=3

            reward1 = self.caluclate_reward(action, current_price,current_atr)

            # 执行动作
            if action == 2:  # Open Long
                if self.position == 0 and self.balance > 0:
                    self.last_portfolio=self.get_value(current_price)

                    self.position_u = self._calculate_position_size(current_atr)
                    self.position_size = self.position_u * (1-Config.TRANSACTION_FEE)/current_price

                    #fee = self.position_u * Config.TRANSACTION_FEE

                    self.balance -= self.position_u
                    self.entry_price = current_price
                    self.empty_entry=0
                    self.position = 1

                    record = 1

                    self.last_best_portfolio = self.get_value(current_price)
                else:
                    print(f'open long is wrong')

            elif action == 4:  # Open short
                if self.position == 0 and self.balance > 0:
                    self.last_portfolio = self.get_value(current_price)

                    self.position_u = self._calculate_position_size(current_atr)
                    self.position_size = self.position_u * (1 - Config.TRANSACTION_FEE) / current_price

                    # fee = self.position_u * Config.TRANSACTION_FEE

                    self.balance -= self.position_u
                    self.entry_price = current_price
                    self.empty_entry = 0
                    self.position = -1

                    record = 1

                    self.last_best_portfolio = self.get_value(current_price)
                else:
                    print(f'open short is wrong')

            elif action==3:

                if self.position == 1 :


                    self._close_position(current_price,False)

                    record = 1
                else:
                    print(f'close long is wrong')
            elif action ==5:
                if self.position == -1:
                    self._close_position(current_price, False)

                    record = 1
                else:
                    print(f'close short is wrong')


        time2 = time.time()
        self.current_portfolio = self.get_value(current_price)


        #self.cal_profit(current_price)
        #print(f'action is {action} record is {record}')
        #if self.position == 0 and action in [1] and record !=1 :
        #    print(f'fatol error is {logit} pos is {pos}')


        action= self.update_state(action,record,stop_triggered,self.open_factor)


        if self.position==0 and self.empty_entry==0:
            self.empty_entry=current_price

        #print(f'position: {self.position}')
        if action ==0 and self.position==0:
            self.open_factor=0


        self.update_position(self.profit_value, 0, self.empty_time, self.holding_time,self.open_factor)


        time3 = time.time()

        self.current_step += 1


        #print(f'in step pos is {self.features['position'].iloc[self.current_step]} cur step is {self.current_step}')



        #done = done or (self.current_step >= self.n_step - 1)

        if action==3 and record == 1:
            done=True
        if action==5 and record == 1:
            done=True


        if self.type=="file":
            time4 = time.time()
            next=self._get_observation()

            #print(f'4 is {time4-time3} 3 is {time3-time2} 2 is {time2-time1}')
            return next, reward, done, action,current_price
        else:
            return reward, done, action, current_price


    def get_value(self,curprice):
        if self.position == 1 :
            current_value = self.balance + self.position_u + self.position_size *(curprice-self.entry_price)
        elif self.position == -1 :
            current_value = self.balance + self.position_u + self.position_size*(self.entry_price - curprice)
        else :
            current_value = self.balance

        return current_value

    def get_recent(self):
        #len=Config.WINDOW_SIZE
        #print(f"shape is {self.features.shape}")
        #print(self.features)
        data= list(self.features)
        return data


    def getnextdata(self, num):
        """
        获取数据批次，num 表示批次的编号，从0开始。
        每个批次的大小为 (Config.PPO_STEPS, Config.WINDOW_SIZE, 特征数量)
        如果最后一批次不足 Config.PPO_STEPS ，则返回剩余的数据
        """
        start_idx = num * Config.PPO_STEPS+1
        end_idx = start_idx + Config.PPO_STEPS

        # 检查是否超出数据长度，如果超出，就调整为最后一部分的数据
        if end_idx > self.n_step-self.window_size:
            end_idx = self.n_step-self.window_size

        # 计算返回数据的批次大小
        batch_size = end_idx - start_idx

        # 提取时间序列数据，按 Config.WINDOW_SIZE 的窗口大小切分
        data = []
        for i in range(start_idx,end_idx):
            start_time_idx = i
            end_time_idx = i + self.window_size
            #print(f' start is {start_time_idx} endi is{end_time_idx}')

            # 获取时间序列数据并按时间窗口截取
            seq_data = self.features[start_time_idx:end_time_idx]

            data.append(seq_data)

        # 转换为 (batch_size, Config.WINDOW_SIZE, 特征数量) 的格式
        return np.array(data).astype(np.float32)






