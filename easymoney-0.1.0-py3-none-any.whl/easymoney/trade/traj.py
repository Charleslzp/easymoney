import math
import numpy as np

class TrajManage:
    def __init__(self):
        self.Trajlist = []
        self.finallist = []
        self.current_trade = []
        self.trade_open = False
        self.price_history = []
        self.global_step = 0

    def process_data(self, reward, act, data, done, values, price, logit, isforce,vol):
        self.price_history.append({'step': self.global_step, 'price': price})

        if act in [2, 3, 4]:  # 只关心开仓（2）、加仓（3）、平仓（4）
            point = {
                'action': act,
                'data': data,
                'values': values,
                'logit': logit,
                'price': price,
                'reward': reward,
                'allocated_reward': 0.0,
                'is_forced': isforce,
                'vol': vol,
                'step': self.global_step,
            }
            self.Trajlist.append(point)

            # 开仓
            if act == 2:
                if self.trade_open:
                    self._force_close_trade()
                self.trade_open = True
                self.current_trade.append(point)

            # 加仓
            elif act == 3:
                if self.trade_open:
                    self.current_trade.append(point)

            # 平仓
            elif act == 4:
                if self.trade_open:
                    self.current_trade.append(point)
                    if reward<0.01:
                        reward=-0.01
                    self._allocate_reward(reward)
                    self._finalize_trade(reward)

        self.global_step += 1

        if done:
            if self.trade_open:
                self._force_close_trade()

    def _allocate_reward(self, total_reward):
        if len(self.current_trade) == 0:
            return

        open_point = self.current_trade[0]
        close_point = self.current_trade[-1]
        middle_points = self.current_trade[1:-1]
        num_adds = len(middle_points)

        # ==== 奖励分配比例 ====
        r_open_base = 0.55 * total_reward + 0.01
        r_add = 0.25 * total_reward
        r_close = 0.2 * total_reward

        # ==== 开仓基础奖励 ====
        open_point['allocated_reward'] = r_open_base

        # ==== 加仓奖励 ====
        if num_adds > 0:
            add_per_point = r_add / num_adds
            for point in middle_points:
                point['allocated_reward'] = add_per_point

        # ==== 关仓奖励 ====
        close_point['allocated_reward'] = r_close

        # ==== 盈利增强 ====
        if total_reward > 0:
            for point in self.current_trade:
                point['allocated_reward'] *= 1.1

    def _force_close_trade(self):
        self.current_trade = []
        self.trade_open = False

    def get_final_data(self):
        result = self.finallist.copy()
        self.finallist = []
        return result

    def _finalize_trade(self, total):
        if not self.current_trade:
            return

        # === 1. 计算奖励
        raw_advs = [float(p['allocated_reward']) - float(p['values']) for p in self.current_trade]

        # === 2. 标准化奖励
        mean = np.mean(raw_advs)
        std = np.std(raw_advs)
        std = max(std, 1e-6)  # 防止除以0

        norm_advs = [(a - mean) / std for a in raw_advs]

        # === 3. 写入结果
        for point, norm_adv in zip(self.current_trade, raw_advs):
            if point.get('is_forced', False):
                continue  # 跳过强制动作
            self.finallist.append({
                'action': point['action'],
                'data': point['data'],
                'act_adv': norm_adv,
                'returns': point['allocated_reward'],
                'logit': point['logit'],
                'vol':point['vol']
            })

        self.current_trade = []
        self.trade_open = False