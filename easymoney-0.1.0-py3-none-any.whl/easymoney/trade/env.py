from collections import deque
from collections import deque

import gym
from gym import spaces
import numpy as np
import math
from easymoney.run.configs import Config
import pandas as pd
import os
import time
import torch
import random
import torch.nn.functional as F
from torch.distributions import Categorical




class TradingEnv(gym.Env):


    def __init__(self,df=None,type="file"):
        super(TradingEnv, self).__init__()

        self.balance = Config.INITIAL_BALANCE  # 关键：余额重置
        self.window_size = Config.WINDOW_SIZE
        self.current_step = self.window_size + 1

        self.position = 0
        self.position_size = 0.0
        self.position_u = 0.0
        self.entry_price = 0.0

        self.holding_time = 0

        self.position_times=0
        self.cooldown=0

        self.empty_time = 0
        self.type=type
        self.max_time=0
        self.dir=0
        self.act_valid=[]
        self.probs=[]
        self.need_stop_win=True

        self.pos_state={
            "pos":0,
            "profit":0,
            "act":0,
            "dur":0,
            "stop":0,
            "position_size":0
        }



        if type=="file":
            #self.df = df.reset_index(drop=True)
            #self.df_close = df_close.reset_index(drop=True)

            self.features = df.values

            self.prices = self.features[:,3]
            self.highs = self.features[:,1]
            self.lows = self.features[:,2]

            self.n_step = len(self.features)
        else:
            self.features=deque(maxlen=Config.WINDOW_SIZE)
            self.price=0
            self.n_step=0
            self.df_close=deque(maxlen=Config.WINDOW_SIZE)

    def reset(self):
        self.balance = Config.INITIAL_BALANCE  # 关键：余额重置
        self.window_size = Config.WINDOW_SIZE
        self.current_step = self.window_size + 1

        self.position = 0
        self.position_size = 0.0
        self.position_u = 0.0
        self.entry_price = 0.0

        self.holding_time = 0

        self.position_times = 0
        self.cooldown = 0

        self.empty_time = 0
        self.max_time = 0
        self.dir = 0
        self.act_valid = []
        self.probs = []

        self.pos_state = {
            "pos": 0,
            "profit": 0,
            "act": 0,
            "dur": 0,
            "stop": 0,
            "position_size": 0
        }

    def add_data(self,df):
        tempdata=[0]*len(Config.FEATURES)
        index=0
        for i in Config.FEATURES:
            #print(f'x is {index} i is {i}')
            tempdata[index]=df[i]
            index+=1




        #print(tempdata)
        self.features.append(tempdata)
        #print(f'dflcose {df_close} , 0 is {df_close[1]}')

        self.price = df["close"]
        self.n_step+=1

    def _update_force_probs(self,  logit):
        """
        用于强制动作（非策略采样）发生时，获取对应动作的 softmax 概率并存储。

        参数：
            real_act: int，实际执行的强制动作
            logit: Tensor，模型输出 logits，shape [8]
        """
        probs = F.softmax(logit.view(-1), dim=-1)  # 全体动作的概率
        self.probs = probs  # 仍然赋值，为后续兼容 act_valid 的逻辑
        self.act_valid = list(range(8))  # 所有动作都有效（强制动作不受限制）

    def dist_env(self, logit, type=1):
        """
        根据 logit 和当前仓位状态选择合法动作。
        :param logit: Tensor, 模型输出 logits，shape [1, 5]
        :param type: int, 1 为验证（最大概率），其他为训练（采样）
        :return: (是否强制动作: int, 动作: int)
        """
        logit = logit.view(-1)

        max_empty = Config.EMPTY_TIME
        max_hold = Config.HOLD_TIME
        min_inter = 4

        # ==== 合法动作 ====
        if self.position == 0:
            act_valid = [0, 2]  # 空仓状态：保持 or 开仓
        else:
            act_valid = [1, 3, 4]  # 持仓状态：持有，加仓，平仓

        self.act_valid = act_valid
        valid_logits = torch.tensor([logit[i] for i in act_valid], device=logit.device)

        # ==== 动作选择函数 ====
        def sample_action(logits, act_valid, sample_type):
            probs = F.softmax(logits, dim=-1)
            self.probs = probs
            if sample_type == 1:
                act_idx = torch.argmax(probs).item()
            else:
                dist = torch.distributions.Categorical(probs)
                act_idx = dist.sample().item()
            return act_valid[act_idx]

        act = sample_action(valid_logits, act_valid, type)
        self.cooldown += 1
        ret = act

        # === 强制开仓 ===
        if self.empty_time >= max_empty and self.position == 0 and self.cooldown > min_inter:
            if np.random.rand() < 0.5:
                self.cooldown = 0
                force_act = 2  # 强制开仓（不关心方向）
                self._update_force_probs(logit)
                return 1, force_act
            self._update_force_probs(logit)
            return 1, 0

        # === 强制平仓 ===
        if self.holding_time >= max_hold and self.position != 0 and self.cooldown > min_inter:
            if np.random.rand() < 0.5:
                self.cooldown = 0
                force_act = 4  # 强制平仓
                self._update_force_probs(logit)
                return 1, force_act
            self._update_force_probs(logit)
            return 1, 1  # 正常持仓

        # === 正常行为判定 ===
        if self.position == 0:
            if act == 2 and self.cooldown > min_inter:
                self.cooldown = 0
                ret = act
            else:
                ret = 0
        else:
            if act == 3 and self.position_times < Config.MAX_POS_TIMES and self.cooldown > min_inter:
                self.cooldown = 0
                ret = act
            elif act == 4 and self.position_times > 0 and self.cooldown > min_inter:
                self.cooldown = 0
                ret = act

            else:
                ret = 1  # 默认继续持仓

        return 0, ret





    def _get_observation(self):
        """获取 (window_size, feature_dim) 的特征窗口"""
        start_idx = max(0, self.current_step - self.window_size+1 )
        end_idx = self.current_step+1

        #ret = pd.DataFrame(self.features)
        if self.type == "file":
            obs=self.features[start_idx:end_idx,6:]
        else:
            features_array = np.array(self.features)  # self.features 是 deque

            obs = features_array[:, 6:]

        #with pd.option_context('display.max_rows', None,
        #                       'display.max_columns', None,
        #                       'display.width', 1000,
        #                       'display.max_colwidth', 20):
        #    print(obs.tail(10))
        #print()

        #print(f"obs pos is {obs["position"].iloc[-1]} curstep is {self.current_step}")
        ret_data = {
            "data": obs,
            "state": self.pos_state
        }

        return ret_data

    def _check_win(self,price):
        profit_base=0


        if self.dir==1:
            profit_base= (price - self.entry_price)/(self.entry_price+1e-9) - 2*Config.TRANSACTION_FEE
        else:
            profit_base = -(price - self.entry_price) / (self.entry_price + 1e-9) - 2 * Config.TRANSACTION_FEE

        min = 0.001

        profit = profit_base // min

        if profit > Config.RISK_STOP_WIN:
            return True
        return False


    def _check_stop(self, price):
        if self.position==0:
            return False
        need_stop_win=True
        """动态止损检查: 根据当前市场波动动态调整止损"""
        #profit_base = (self.get_value(current_atr)-self.last_portfolio) / Config.TRANSACTION_PER
        if self.dir==1:
            profit_base= (price - self.entry_price)/(self.entry_price+1e-9) - 2*Config.TRANSACTION_FEE
        else:
            profit_base = -(price - self.entry_price) / (self.entry_price + 1e-9) - 2 * Config.TRANSACTION_FEE
            #profit_base=-profit_base


        min=0.001

        profit = profit_base// min


        if self.position !=0 and profit <=0 :
            #if self.position_times > 1:
                #profit *=  self.position_times

            if abs(profit) > Config.RISK_STOP_LOSS:

                #print(f'profit_base is {profit} price is {price} entry si {self.entry_price}')

                return True



        return False



    def _close_position(self, current_price,stop_type):


        """平仓通用逻辑: 计算盈亏 + 扣手续费"""
        if stop_type == 1:
            position_size= self.position_size / self.position_times
            postion_u=self.position_u/self.position_times
            self.position_size-=position_size
            self.position_u-=postion_u
            self.position_times-=1
        else:
            position_size = self.position_size
            postion_u = self.position_u
            self.position_u=0
            self.position_size=0
            self.position_times=0

        if self.dir == 1:  # 多头仓位
            pnl = position_size * (current_price - self.entry_price)  # 计算盈亏
            #print(f'1 pnl is {pnl}')
        else:  # 空头仓位
            pnl = position_size * (self.entry_price - current_price)  # 计算盈亏
            #print(f'-1 pnl is {pnl}')

        fee = position_size * current_price * Config.TRANSACTION_FEE

        # 计算净盈亏
        net_pnl = pnl - fee

        # 更新账户余额，余额增加盈亏和扣除手续费后的净额
        self.balance += net_pnl + postion_u


        if  self.position_times==0:
            total=self.balance-Config.INITIAL_BALANCE
            #print(f'profit is {total} posizie is {position_size} current price is {current_price} us {postion_u}' )
        else:
            total=net_pnl

        total=total/100
        #total*=3

        if abs(total) < 0.05:

            if total >0:
                total = 0.05
            else:
                total = -0.05

        if abs(total) > 0.8:

            if total >0:
                total = 0.8
            else:
                total = -0.8

        total *= 3

        #print(f'total is {total}')



        # 清空仓位
        if self.position_times==0:
            #print(f'dir is {self.position} entry is {self.entry_price} close is {current_price} pnl is {total} self.position_size is {self.position_size}')
            self.position = 0
            self.position_u=0.0
            self.position_size=0
            self.entry_price = 0.0


        return total

    def _open_position(self, current_price,vol):

        """平仓通用逻辑: 计算盈亏 + 扣手续费"""

        self.position_u += Config.TRANSACTION_PER*(1- Config.TRANSACTION_FEE) * vol
        open_fee = self.position_u * Config.TRANSACTION_FEE
        invest=Config.TRANSACTION_PER*vol-open_fee
        self.position_size +=invest / current_price

        #fee = Config.TRANSACTION_PER * Config.TRANSACTION_FEE

        self.balance -= Config.TRANSACTION_PER * vol
        self.entry_price = self.position_u / self.position_size
        self.empty_time=0
        self.position = 1


        #print(f'prcie is {current_price} fee is {Config.TRANSACTION_FEE} posizie is {self.position_size} entry is {self.entry_price} us is {self.position_u}')

        self.position_times+=1
        if self.position_times>self.max_time:
            self.max_time=self.position_times
    def updata_state(self,act,curprice,stop):

        profit=0
        if self.position!=0:

            if self.dir == 1:
                profit = (curprice - self.entry_price) / (self.entry_price + 1e-9) - 2 * Config.TRANSACTION_FEE
            else:
                profit = -(curprice - self.entry_price) / (self.entry_price + 1e-9) - 2 * Config.TRANSACTION_FEE

            profit*=30
            #profit-=2*Config.TRANSACTION_FEE
        if self.position!=0 :
            dur=self.holding_time/Config.HOLD_TIME
        else:
            dur=self.empty_time/Config.EMPTY_TIME



        self.pos_state = {
            "pos": self.position,
            "profit": profit,
            "act": act,
            "dur": dur,
            "stop": stop,
            "position_size":self.position_times/Config.MAX_POS_TIMES
        }




    def step(self, action,vol):
        """执行环境步进逻辑"""
        done = False
        time1=time.time()
        reward=0
        if self.type=="file":
            current_price = self.prices[self.current_step]



        else:
            current_price=self.price
            self.current_step=-1
            last_element = self.features[-1]

        stop_wind = self._check_win(current_price)

        stop_trig = self._check_stop(current_price)

        real_do = False
        #print(f'pos 1 is {self.position}')
        if stop_trig:
            reward=self._close_position(current_price, 2)
            real_do = True
            #print(f'reward is {reward}')

            action=4

            #print(f'pos 13 is {self.position} action is {action}')

        else:
            if action in [2,3] and self.position_times<Config.MAX_POS_TIMES :
                self._open_position(current_price,vol+0.3)
                real_do=True


            elif action ==4  or self.position_times > Config.MAX_POS_TIMES :
                #self.need_stop_win = False

                #if self.need_stop_win != True:
                #    stop_wind=True

                if stop_wind== True or self.holding_time>=Config.HOLD_TIME:
                    reward=self._close_position(current_price,2)
                    real_do = True
                else :
                    action = 1

        if real_do != True:
            if self.position!=0:
                self.holding_time+=1
            else:
                self.empty_time+=1

        #print(f'pos 12 is {self.position}')
        self.updata_state(action,current_price,stop_trig)


        if action ==4:

            done=True



        else:

            self.current_step += 1


        if self.type=="file":
            time4 = time.time()
            next=self._get_observation()

            #print(f'4 is {time4-time3} 3 is {time3-time2} 2 is {time2-time1}')
            return next, reward, done, action,current_price
        else:
            return reward, done, action, current_price








