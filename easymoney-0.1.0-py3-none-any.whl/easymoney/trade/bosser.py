
import time
import pandas as pd
from easymoney.trade.traj import TrajManage

import random
from multiprocessing import Process, Manager, current_process
from easymoney.run.configs import Config
from easymoney.trade.env import TradingEnv
from easymoney.data.feature import FeatureEngine
import numpy as np
from easymoney.model.tft_model import EasyMoneyModel
from easymoney.agent.ppo_agent  import PPOAgent
import json

import torch

from tqdm import tqdm
from collections import deque
import os
from easymoney.trade.profit_record import record_manager
from easymoney.run.dataloader import load_shared_array
from multiprocessing import shared_memory
from easymoney.run.dataloader import get_satart



os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "backend:native"
class model_bosser:
    def __init__(self):
        self.device = self.get_device()
        self.trend_csv = "easymoney/data/trend_raw.csv"
        self.trend_lable = self.init_trendlabel(self.trend_csv)
        self.agent=PPOAgent(4,1)
        self.asset_list = self.init_assetlist()
        self.agent.model.to(self.device)
        self.last_update=0
        self.ckeck_len=7000
        self.error=[0,0,0,0]
        self.act0=[]
        self.act1=[]
        self.act2=[]
        self.act3=[]
        self.profit=0
        self.begin=0
        self.last=0
        self.badlist=[]
        self.goodlist = []
        self.bad_count=0
        self.good_count = 0
        self.best_profit=[]


        #self.env_list=self.init_env()



        self.round=0
        self.version=-1
        self.longqueue = deque(maxlen=30)  # 自动FIFO淘汰
        self.shortqueue = deque(maxlen=10)
        self.stop_count=0
        self.env=None

        self.path=self.get_path()
        self.agent.load_model(self.path)
        if not os.path.exists(Config.BEST_MODEL_PATH):
            self.agent.bestmodel=-100
        print(f'load best is {self.agent.bestmodel}')

    def init_assetlist(self):
        with open(Config.ASSETS_PATH, 'r') as file:
            content = file.read()
            datalist = json.loads(content)
            return datalist
        return None

    def init_env(self):
        env_list=[]
        for x in range(len(self.asset_list)):

            df = pd.read_csv(f'data/result/{self.asset_list[x]}.csv')
            #print(f'begin boss')
            df = df[Config.FEATURES]

            if len(df) * 0.2 < 1000:
                len_d = int(len(df) * 0.5)
            else:
                len_d = int(len(df) * 0.2)
            df = df.tail(int(len(df) * 0.3))
            df = df.head(int(len(df) * 0.66))
            env_t=TradingEnv(df)
            env_list.append(env_t)

        return env_list

    def init_trendlabel(self, path):
        data = pd.read_csv(path, parse_dates=["timestamp"])
        data["date"] = data["timestamp"].dt.date  # 只取日期部分
        labels = dict(zip(data["date"], data["trend"]))  # 构造 date -> label 字典
        return labels

    def _chose_data_bytime(self, shm_meta_list):
        start, time_str = self.chose_new_trade(shm_meta_list)
        # print(time_str)
        # if isinstance(time_str, str):
        time_str = pd.to_datetime(time_str, unit='s').date()  # 如果输入的是字符串，转换为 datetime 对象
        # print(time_str)
        td = self.trend_lable.get(time_str, None)
        # print(td)

        return td, start

    def choose_new(self, shm_meta_list):
        if Config.DIR_ENABLE==-1:
            td = 1
            tart=-1
        else:
            td = -1
            tart=1
        start = None
        while td != tart:
            td, start = self._chose_data_bytime(shm_meta_list)

        return start

    def chose_new_trade(self, shm_meta_list):
        env_num = np.random.randint(0, len(self.asset_list))
        # print(f'env_num is {env_num}')
        # df=data[env_num]
        meta = shm_meta_list[env_num]
        #print(meta)
        shm = shared_memory.SharedMemory(name=meta["name"])

        # print(f'datalen is {len(meta)} df is {meta}')

        arr = np.ndarray(meta["shape"], dtype=np.float32, buffer=shm.buf)
        start=get_satart(len(arr),0.8,0.9)

        # check_len = datalen - Config.PPO_STEPS - Config.WINDOW_SIZE - 2
        # print(f'cl is {check_len}')
        #start = np.random.randint(datalen1, datalen2)
        end = start + Config.PPO_STEPS+Config.WINDOW_SIZE+1

        #print(f'total len is {datalen1} start is {datalen2}')


        #arr=
        init_data = arr[start:end].copy()
        df = pd.DataFrame(init_data, columns=Config.FEATURES)  # 再加回列名
        #print(df.head(5))
        #print(f'start is {start} end is {end} asset is {df["asset"].iloc[-1]}')

        if self.env != None:
            del self.env
        self.env = TradingEnv(df)
        self.env.dir=Config.DIR_ENABLE
        time_str = self.env.features[self.env.current_step, 5]
        start_data = self.env._get_observation()

        return start_data,time_str




    def get_path(self):
        if Config.TRAINTYPE == "base":
            return Config.PRE_TRADEL_PATH
        else:
            return Config.FINAL_TRADEL_PATH

    def get_device(self):
        #device_id = random.choice([0, 1])  # 假设你有两个GPU

        device_id=1

        torch.cuda.set_device(device_id)  # 设置当前进程使用的GPU
        device = torch.device(f'cuda:{device_id}' if torch.cuda.is_available() else 'cpu')
        return device


    def check_state(self,instument):
        if self.last_update + 30000 < self.version:
            self.agent.save_model(self.path)
            self.last_update = self.version
            instument.put(1)



        #self.agent.flush_sum()

    def check_ealystop(self,  profit):
        ret = False
        if self.version >=500000 and Config.EARLY_STOPPING ==True:
            self.longqueue.append(profit)
            self.shortqueue.append(profit)

            if len(self.longqueue)==30:
                longmean= sum(self.longqueue)/len(self.longqueue)
                shortmean= sum(self.shortqueue)/len(self.shortqueue)
                if shortmean<longmean:
                    self.stop_count+=1
                else:
                    self.stop_count=0
                print(f'profit short  is {shortmean},long is {longmean}, stop count is {self.stop_count}')
                if self.stop_count>10:
                    ret = True

        return ret



    def check_work(self,list,begin,last,rc_m):

        if len(list)>0:
            reward= np.mean(list)
        else:
            reward = None
        """
        self.env.profit.getprofit()
        #profit=self.env.current_portfolio-Config.INITIAL_BALANCE
        profit = self.profit
        self.profit=0
        radio=profit/self.ckeck_len
        if profit > 0:
            colored_value = f"\033[32m{profit:4f}\033[0m"  # 绿色
        else:
            colored_value = f"\033[31m{profit:4f}\033[0m"  # 红色

        if radio > 0:
            radio_show = f"\033[32m{radio:4f}\033[0m"  # 绿色
        else:
            radio_show = f"\033[31m{radio:4f}\033[0m"  # 红色

        print(f"profit is{colored_value}  prorit radio is{radio_show}")"""

        if len(self.act0)>0:
            print(f'act0 max {max(self.act0)} min is {min(self.act0)} sum is {sum(self.act0)} mean is {np.mean(self.act0)}')

        if len(self.act1)>0:
            print(f'act1 max {max(self.act1)} min is {min(self.act1)} sum is {sum(self.act1)} mean is {np.mean(self.act1)}')

        if len(self.act2)>0:
            print(f'act2 max {max(self.act2)} min is {min(self.act2)} sum is {sum(self.act2)} mean is {np.mean(self.act2)}')

        if len(self.act3)>0:
            print(f'act3 max {max(self.act3)} min is {min(self.act3)} sum is {sum(self.act3)} mean is {np.mean(self.act3)}')

        print(f'total reward is {sum(self.act0)+sum(self.act1)+sum(self.act2)+sum(self.act3)}')

        print(f'begin is {begin} last is {last}')

        if self.good_count>0:
            print(f'good open is mean({sum(self.goodlist)/self.good_count}) max is {max(self.goodlist)} min is {min(self.goodlist)}')

        if self.bad_count>0:
            print(f'bad open is mean({sum(self.badlist)/self.bad_count}) max is {max(self.badlist)} min is {min(self.badlist)}')

        win,good_radio,totalvalues,hold_pp,empty_pp = rc_m.print_record()
        print(f'best radio is {np.mean(self.best_profit)}')

        self.best_profit = []
        """"
        print(f'best radio is {np.mean(self.best_profit)}')
        
        self.best_profit=[]
        if len(self.best_profit) == 0:
            print(f'big error')
            radio = win
        else:
            meadian=np.percentile(self.best_profit, 50)
            b_25=np.percentile(self.best_profit, 25)
            b_75 = np.percentile(self.best_profit, 75)
            b_95 = np.percentile(self.best_profit, 95)

            print(f'percentile, 25 is {b_25} 50 is {meadian} b_75 is {b_75} b_95 is {b_95}')

            best = np.mean(self.best_profit)"""

        radio = good_radio+win*20

        if totalvalues<0:
            radio-=2

        if hold_pp>Config.HOLD_TIME:
            radio -=4

        if empty_pp>Config.EMPTY_TIME:
            radio -= 4

        if empty_pp <= 20 or hold_pp ==4:
            radio -= 4

        print(f'good_radio is {good_radio} wind is {win} totalvalues is {totalvalues} fr is {radio}')
        rc_m.reset()
        self.goodlist=[]
        self.badlist=[]
        self.good_count=0
        self.bad_count=0


        self.act0=[]
        self.act1 = []
        self.act2 = []
        self.act3 = []

        #self.env.reward.print_metrics()

        #print(f'err act is {self.error}')
        self.error=[0,0,0,0]

        #total_trade = good_count + bad_count
        #base_con = total / (total_trade + 1e-9)

        if radio> self.agent.bestmodel  :
            last=self.agent.bestmodel
            self.agent.bestmodel = radio
            if Config.TRAINTYPE =="base":
                self.agent.save_model(Config.BEST_MODEL_PATH)
            else:
                self.agent.save_model(Config.BEST_MODEL_FN_PATH)
            self.agent.save_model(self.path)
            #self.agent.flush_sum()

            print(f"find best is {radio}, last is {last} steps is {self.version}")
            self.last_update=self.version
        return radio

    def get_model(self,consumer_queue):
        if consumer_queue.qsize==10:
            print(f'chaeck to ready sleep')
            time.sleep(30)
        else:
            time.sleep(20)
        newmodle = consumer_queue.get()

        if self.version < newmodle['version']:
            if torch.cuda.device_count() > 1 and Config.NEED_MOREGPU == True:
                self.agent.model.module.load_state_dict(newmodle['model'])
                print(f'boss read wrong device ')
            else:
                self.agent.model.load_state_dict(newmodle['model'])
            self.version=newmodle['version']
            self.agent.train_round=self.version
            print(f'get ready to check {self.version}')

        self.agent.model =self.agent.model.to(self.device)

        if self.last_update==0:
            self.last_update=self.version

        self.agent.model.eval()

        return

def validator_task(consumer_queue, instument,stop_event,shm_meta_list):

    boss = model_bosser()

    profit_record=record_manager()

    try:
        while not stop_event.is_set():
            max_collect=boss.ckeck_len
            collect_data = 0

            boss.get_model(consumer_queue)

            reward_list = []
            done=False
            with tqdm(total=max_collect, desc=f"boss check work round {boss.round}") as pbar:


                while not (collect_data > max_collect and done ==True):

                    data= boss.choose_new(shm_meta_list)
                    done=False
                    step = 0
                    open=0
                    mem = TrajManage()
                    pp=0

                    while done!=True:


                        #print(f'step is {step}')
                        data_t = boss.agent.model.create_input_dict(data,boss.device)

                        #print(f'shape is {data_t.shape}')
                        with torch.no_grad():
                            logit,values,vol=boss.agent.model(data_t)

                        #boss.agent.model.debug=False

                        isforce,action=boss.env.dist_env(logit)

                        #if action == 2 or action ==6 :
                        #    print(f'dir is {dir} time is {boss.env.empty_time} action is {action}')

                        #print(f'action is {action} logit is {logit}')
                        #print(f'rawact is {action} ')
                        next_state, reward, done, real_act, price= boss.env.step(action,vol.item())

                        #mem.process_data(reward, real_act, None, done, values.clone().cpu(), price,
                        #                 logit.squeeze(0)[action].clone().cpu())
                        #print(f'real_act is {real_act} action is {action} done is {done}')
                        if real_act==2:
                            open=step
                            #pp=price
                            profit_record.add_new_record(price,0,boss.env,step,boss.env.dir)
                        elif real_act==5:
                            #pp=price
                            open=step
                            profit_record.add_new_record(price,0,boss.env,step,-1)
                        elif done == True :
                            hold=step-open
                            profit_record.close_record(price, hold,boss.env.balance-Config.INITIAL_BALANCE)
                            #print(f'')


                        if done==True :
                            #if mem.best_radio>0:
                            #print(mem.keypoint)
                            boss.best_profit.append(boss.env.max_time)
                            del mem
                            mem = None


                        del logit,data_t



                        data = next_state
                        #if len(data)<120:
                        ##    print(f'len is wrogong {len(data)} cur is  {boss.env.current_step}')

                        collect_data+=1
                        pbar.update(1)
                        step+=1


                profit=boss.check_work(reward_list,0,0,profit_record)
                boss.check_state(instument)
                boss.round+=1
                stop=boss.check_ealystop(profit)
                if stop== True:
                    stop_event.set()
                del reward_list
                time.sleep(15)



    except KeyboardInterrupt:
        pass
    finally:
        print("🚪 验证者退出")
