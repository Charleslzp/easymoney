import time
import random
from multiprocessing import Process, Manager, current_process
from easymoney.run.configs import Config
from easymoney.trade.env import TradingEnv
#from data.feature import FeatureEngine
import json
import numpy as np
from easymoney.model.tft_model import EasyMoneyModel
import torch
import pandas as pd
from easymoney.trade.traj import TrajManage
from multiprocessing import shared_memory

from easymoney.run.dataloader import get_satart


import os

os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "backend:native"



class model_worker:
    def __init__(self,id):
        self.maintask_id = [0, 1, 2, 3, 4, 5]
        self.id = id
        self.device = self.get_device()
        self.trend_csv = "easymoney/data/trend_raw.csv"
        self.trend_lable = self.init_trendlabel(self.trend_csv)
        self.asset_list=self.init_assetlist()
        """
        self.model =EnhancedStrategicTFT(
            hidden_size=Config.TFT_HIDDEN_SIZE_MARKET,
            lstm_layers=Config.TFT_NUM_LAYERS,
            dropout=Config.TFT_DROPOUT,
            attention_head_size=Config.TFT_NUM_HEADS,
            hidden_continuous_size=Config.TFT_HIDDEN_SIZE_POSITION

        ).to(self.device) """
        self.model = EasyMoneyModel(
            input_dim=len(Config.FEATURES) - 7,
            hidden_dim_market=Config.TFT_HIDDEN_SIZE_MARKET,
            hidden_dim_pos=Config.TFT_HIDDEN_SIZE_POSITION,
            num_heads=Config.TFT_NUM_HEADS,
            num_layers=Config.TFT_NUM_LAYERS,
            dropout=Config.TFT_DROPOUT,
            maxlen=Config.WINDOW_SIZE,
            num_assets=100
        ).to(self.device)

        #self.env_list = self.init_env()
        self.env = []

        self.round=0
        self.version=-1
    def init_assetlist(self):
        with open(Config.ASSETS_PATH, 'r') as file:
            content = file.read()
            datalist = json.loads(content)
            return datalist
        return None

    def init_trendlabel(self, path):
        data = pd.read_csv(path, parse_dates=["timestamp"])
        data["date"] = data["timestamp"].dt.date  # 只取日期部分
        labels = dict(zip(data["date"], data["trend"]))  # 构造 date -> label 字典
        #print(labels)
        return labels

    def _chose_data_bytime(self, shm_meta_list):
        start, time_str = self.chose_new_trade(shm_meta_list)
        #print(time_str)
        # if isinstance(time_str, str):
        time_str = pd.to_datetime(time_str, unit='s').date()  # 如果输入的是字符串，转换为 datetime 对象
        #print(time_str)
        td = self.trend_lable.get(time_str, None)
        #print(td)

        return td, start

    def choose_new(self, shm_meta_list):
        if Config.DIR_ENABLE == -1:
            td = 1
            tart = -1
        else:
            td = -1
            tart = 1
        start = None
        while td != tart:
            td, start = self._chose_data_bytime(shm_meta_list)

        return start

    def init_env(self):
        env_list=[]
        for x in range(len(self.asset_list)):

            df = pd.read_csv(f'data/result/{self.asset_list[x]}.csv')
            #print(f'begin boss')
            df = df[Config.FEATURES]
            if len(df)*0.2 <1000:
                len_d= int(len(df) * 0.5)
            else:
                len_d = int(len(df) * 0.7)
            df=df.head(len_d)
            if  df["open"].eq(0).any() :
                print(f'you 0 in {self.asset_list[x]}')


            env_t=TradingEnv(df)
            env_list.append(env_t)

        return env_list

    def chose_new_trade(self, shm_meta_list):
        time1=time.time()
        env_num = np.random.randint(0, len(self.asset_list))
        # print(f'env_num is {env_num}')
        # df=data[env_num]
        meta = shm_meta_list[env_num]
        shm = shared_memory.SharedMemory(name=meta["name"])

        # print(f'datalen is {len(meta)} df is {meta}')

        arr = np.ndarray(meta["shape"], dtype=np.float32, buffer=shm.buf)

        start=get_satart(len(arr),0,0.8)

        #datalen = int(len(arr) * 0.8)
        # datalen2 = int(len(meta) * 0.8)

        # check_len = datalen - Config.PPO_STEPS - Config.WINDOW_SIZE - 2
        # print(f'cl is {check_len}')
        #start = np.random.randint(0, datalen)
        end = start + Config.PPO_STEPS+Config.WINDOW_SIZE+1

        # arr=
        init_data = arr[start:end].copy()
        df = pd.DataFrame(init_data, columns=Config.FEATURES)  # 再加回列名

        if self.env != None:
            del self.env

        self.env = TradingEnv(df)
        self.env.dir = Config.DIR_ENABLE
        time_str = self.env.features[self.env.current_step, 5]
        start_data = self.env._get_observation()
        time2 = time.time()
        #print(f'used time is ({time2 - time1})')

        return start_data,time_str




    def get_device(self):
        #device_id = random.choice([0, 1])  # 假设你有两个GPU
        if self.id in self.maintask_id:
            device_id = 1  # 假设你有两个GPU
        else:
            device_id=0

        torch.cuda.set_device(device_id)  # 设置当前进程使用的GPU
        device = torch.device(f'cuda:{device_id}' if torch.cuda.is_available() else 'cpu')
        return device


    def get_model(self,consumer_queue):
        if not consumer_queue.empty():
            newmodle = consumer_queue.get(block=False)
        else:
            return

        if self.version < newmodle['version']:
            self.model.load_state_dict(newmodle['model'])
            self.model=self.model.to(self.device)
            self.version=newmodle['version']
            #print(f'getnew version is {self.version}')

        return



def producer_task(producer_queue, consumer_queue,num_producers, stop_event,shm_meta_list):
    worker = model_worker(num_producers)
    fl=len(Config.FEATURES)
    #print(f'start')
    start_backup=False
    model_count=0


    try:
        while not stop_event.is_set():
            done=False

            if model_count%50 == 0 :
                #print(f'kazhule')
                worker.get_model(consumer_queue)
            else :
                model_count+=1


            if not num_producers in worker.maintask_id:
                while producer_queue.qsize()>50:
                    time.sleep(10)


            while producer_queue.qsize()>800:
                time.sleep(9)
                #print(f'启动备用生产者 len is {producer_queue.qsize()}')

            data = worker.choose_new(shm_meta_list)
            #print(f'start')
            done = False
            #step = 0
            #open = 0
            mem = TrajManage()
            #ret_data={}
            #print(f'init price is {worker.env.prices[worker.env.current_step]}  step is { worker.env.current_step}')

            while done!=True:
                time1 = time.time()
                #fea = Config.FEATURES[5:]  # 获取从第5个开始的特征名

                #data_pd  = pd.DataFrame(data, columns=fea)
                #print(f'data _pd is {data_pd['timestamp']}')

                data_t =worker.model.create_input_dict(data,worker.device)
                #print(f'pos in woerker is {data[-1,-5]}')
                time2=  time.time()



                with torch.no_grad():
                    logit,values,vol=worker.model(data_t)
                    #print(vol)
                    #print(f'logit is {logit}')
                    ret_data={key: value.clone().cpu().numpy() for key, value in data_t.items()}

                time3 = time.time()



                isforce,action = worker.env.dist_env(logit,type=2)
                #print(f'logit is {logit} action is {action}')


                #print(f'pos is {worker.env.position}')
                next_state, reward, done, real_act, price= worker.env.step(action,vol.item())

                prob=0
                for index, item in enumerate(worker.env.act_valid):
                    if item== real_act:
                        prob=worker.env.probs[index]

                if real_act!=action:
                    isforce=1
                        #print(prob)
                #if prob == 0:
                #print(f'act is {worker.env.act_valid}  prob is {worker.env.probs} action is {action} realact is {real_act}')

                #print(f'raw action is {action} real is {real_act} pos is {worker.env.position}')
                #print(f'actionsis {real_act} price is {price} bl is {worker.env.balance} pos is {worker.env.position}')
                time4 = time.time()

                #price_next= worker.env.prices[worker.env.current_step]
                #if price_next <= 0 :
                #    print(f'big error curstep is {worker.env.current_step} totoalen is {worker.env.n_step} data is {worker.env.features[worker.env.current_step]}')

                #print("logit shape:", logit.shape)
                #if real_act== 2 or real_act==5 :
                #    print(f'acti is {real_act}')
                mem.process_data(reward,real_act,ret_data,done,values.clone().cpu(),price,prob.item(),isforce,vol.item())
                #print(f'run uesd {time4-time3} logit uesd {time3-time2} input used{time2-time1}')

                if done==True:
                    #print(f'done')
                    #worker.env.rest_best()
                    #print(mem.rewardlist)
                    #print(f' rewardis {reward} reaactis {real_act}')

                    del logit,data_t



                    #if len(mem.formal_mem)>2:
                    #    print(f'find best')
                    if len(mem.Trajlist)>0 :
                        producer_queue.put(mem.finallist)
                        #print(f'len is {len(mem.Trajlist)}')
                    #mem.clear_memory()
                    del mem
                    mem = None

                data = next_state
                #step += 1
                #print(f'next data position is {data['position'].iloc[-1]}')






    except KeyboardInterrupt:
        pass
    finally:
        print(f"🚪 {current_process().name} 退出")
        producer_queue.put(None)  # 发送结束信号

