from easymoney.run.configs import Config
import numpy as np


class record():
    def __init__(self):
        self.buy_price=0
        self.sell_price=0
        self.open_radio=0
        self.profit=0
        self.type=0
        self.hold=0
        self.empty=0
        self.dir=0

    def open_record(self,price,open_radio,type,empty,dir):
        self.buy_price=price
        self.open_radio=open_radio
        self.type=type
        self.empty=empty
        self.dir=dir

    def sell_record(self,price,hold,profit):
        self.sell_price=price
        self.hold=hold
        self.profit=profit
        """
        if self.dir==1:
            self.profit= (self.sell_price - self.buy_price) / self.buy_price - 2 * Config.TRANSACTION_FEE
        elif self.dir==-1:
            self.profit= -(self.sell_price - self.buy_price) / self.buy_price - 2 * Config.TRANSACTION_FEE
        else:
            print(f'big error in reacord_pfofit dir is {self.dir}')

        self.profit*=self.open_radio
        self.profit*=Config.TRANSACTION_PER
        """
        #print(f'profit is {self.profit}')


class record_manager():
    def __init__(self):
        #self.record_list=[]
        self.last_record={}
        self.good_list=[]
        self.bad_list=[]

    def add_new_record(self,price,open_radio,type,empty,dir):
        self.last_record=record()
        self.last_record.open_record(price,open_radio,type,empty,dir)
    def close_record(self,price,hold,profit):
        self.last_record.sell_record(price,hold,profit)
        #self.record_list.append(self.last_record)
        if self.last_record.profit>0:
            self.good_list.append(self.last_record)
        else:
            self.bad_list.append(self.last_record)
        #print(f'profit is {self.last_record.profit}')
        del self.last_record

        self.last_record={}

    def reset(self):
        del self.good_list,self.bad_list
        self.good_list=[]
        self.bad_list=[]
        self.last_record={}

    def print_record(self):
        print('########盈利情况##########')
        good_profit_list= [r.profit for r in self.good_list]
        bad_profit_list=[r.profit for r in self.bad_list]

        good_profit_sum=sum(good_profit_list)
        bad_profit_sum=sum(bad_profit_list)
        good_profit_count=len(good_profit_list)
        bad_profit_count=len(bad_profit_list)
        total_trade=good_profit_count+bad_profit_count
        if good_profit_count!=0 and bad_profit_count!=0:
            good_radio=-(good_profit_sum/good_profit_count) /  (bad_profit_sum/bad_profit_count)

        total_profit=good_profit_sum+bad_profit_sum
        if total_profit > 0:
            colored_value = f"\033[32m{total_profit:4f}\033[0m"  # 绿色
        else:
            colored_value = f"\033[31m{total_profit:4f}\033[0m"  # 红色

        print(f'总盈利:{colored_value},总交易:{total_trade}(笔),胜率:{good_profit_count/total_trade} ')
        if good_profit_count != 0 and bad_profit_count != 0:
            print(f'盈亏比:{good_radio},总盈利（{good_profit_sum}）最大盈利:{max(good_profit_list)},总亏损（{bad_profit_sum}）最大亏损:{min(bad_profit_list)}')

        print('########持仓情况##########')
        good_hold_list = [r.hold for r in self.good_list]
        bad_hold_list = [r.hold for r in self.bad_list]
        good_empty_list = [r.empty for r in self.good_list]
        bad_empty_list = [r.empty for r in self.bad_list]
        total_hold=sum(bad_hold_list)+sum(good_hold_list)
        total_empty = sum(good_empty_list) + sum(bad_empty_list)
        hold_pp=total_hold/total_trade
        empty_pp=total_empty/total_trade
        print(f'总平均持仓:{hold_pp},总平均空仓:{empty_pp}')
        if good_profit_count>0:
            print(f'盈利平均持仓:{sum(good_hold_list)/good_profit_count}:盈利最大持仓:{max(good_hold_list)},盈利最小持仓:{min(good_hold_list)}')
            print(f'盈利平均空仓:{sum(good_empty_list)/good_profit_count}:盈利最大空仓:{max(good_empty_list)},盈利最小空仓:{min(good_empty_list)}')

        if bad_profit_count>0:
            print(f'亏损平均持仓:{sum(bad_hold_list)/bad_profit_count}:亏损最大持仓:{max(bad_hold_list)},亏损最小持仓:{min(bad_hold_list)}')
            print(f'亏损平均空仓:{sum(bad_empty_list)/bad_profit_count}:亏损最大空仓:{max(bad_empty_list)},亏损最小空仓:{min(bad_empty_list)}')

        print('########多空情况##########')
        long_good_list=[]
        short_good_list = []
        for trade in self.good_list:
            if trade.dir==1:
                long_good_list.append(trade)
            elif trade.dir == -1:
                short_good_list.append(trade)
            else:
                print(f'big error in good #多空情况 dir is {trade.dir}')
        long_bad_list = []
        short_bad_list = []
        for trade in self.bad_list:
            if trade.dir == 1:
                long_bad_list.append(trade)
            elif trade.dir == -1:
                short_bad_list.append(trade)
            else:
                print(f'big error in bad #多空情况 dir is {trade.dir}')


        good_long_len=len(long_good_list)
        good_short_len = len(short_good_list)
        bad_long_len = len(long_bad_list)
        bad_short_len = len(short_bad_list)
        if good_short_len+bad_short_len !=0 and good_long_len+bad_long_len !=0:
            dir=0
            print(f'做多（{good_long_len+bad_long_len})笔，做空（{good_short_len+bad_short_len}）笔，做多胜率（{good_long_len/(good_long_len+bad_long_len)}），做空胜率（{good_short_len/(good_short_len+bad_short_len)}）')
        elif good_short_len+bad_short_len ==0:
            print(f'只有做多（{good_long_len+bad_long_len})笔，做多胜率（{good_long_len/(good_long_len+bad_long_len)}）')
            dir=1
        elif good_long_len+bad_long_len ==0:
            dir=-1
            print(f'只有做空（{good_short_len+bad_short_len})笔，做空胜率（{good_short_len/(good_short_len+bad_short_len)}）')
        if dir in [0,1]:
            max_long_profit=0
            max_long_lose = 0
            long_profit=0
            long_lose = 0
            for trade in long_good_list:
                long_profit+=trade.profit
                if trade.profit>max_long_profit:
                    max_long_profit=trade.profit
            for trade in long_bad_list:
                long_lose+=trade.profit
                if trade.profit<max_long_lose:
                    max_long_lose=trade.profit
            print(f'做多总利润（{long_profit+long_lose}），最大利润（{max_long_profit}），最大亏损（{max_long_lose}）')

        if dir in [0, -1]:
            max_short_profit = 0
            max_short_lose = 0
            short_profit = 0
            short_lose = 0
            for trade in short_good_list:
                short_profit += trade.profit
                if trade.profit > max_short_profit:
                    max_short_profit = trade.profit
            for trade in short_bad_list:
                short_lose += trade.profit
                if trade.profit < max_short_lose:
                    max_short_lose = trade.profit
            if good_short_len+bad_short_len !=0:
                print(f'做空总利润（{short_profit + short_lose}），最大利润（{max_short_profit}），最大亏损（{max_short_lose}）')



        return good_profit_count/total_trade,good_radio,total_profit,hold_pp,empty_pp

