import torch

class Config:
    # ========== 基础配置 ==========
    SEED = 42
    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
    MIXED_PRECISION = False  # 是否使用混合精度
    DIR_ENABLE = 1
    NEED_MOREGPU = False
    DEBUG_KERNEL = False
    BACKTEST=0.2
    FREEZE_POLICY=False
    Single_Value = False
    EMPTY_ACTION_IDX=0
    DEBUG_LOG = True
    NEED_DIR=0

    # ========== 数据相关 ==========
    DATA_PATH_ADAPTER = "btc_5m_p2.csv"  # CSV 文件路径
    DATA_PATH_BASE = "btc_5m_p1.csv"
    DATA_PATH_FINAL = "btc_5m_new.csv"
    SUM_WRITER= "./sumwriter"
    ASSETS_PATH='./easymoney/data/data_list.json'

    #all_feture1
    FEATURES = [
        "open", "high", "low", "close", "volume",
        "timestamp", "asset",
        # "open_5m", "high_5m", "low_5m",
        "close_15m", "volume_15m",

        "EMA3_15m", "RSI_15m", "WILLR_15m", "BBANDS_15m", "MACD_15m", "OBV_15m",
        "price_change_pct_1bar_raw", "close_raw_ema10_distance_pct",
        "MACD_Signal_15m",  "KDJ_15m",
        "ADX_15m",  "CROSS_RSI_WILL_15m",
        "price_change_pct_3bar_raw","price_change_pct_5bar_raw",
        #"ATR_15m","MACD_hist_15m",

        # "EMA10_1h", "EMA20_1h",  "RSI_1h", "ATR_1h", "WILLR_1h",  "MACD_1h", "MACD_Signal_1h",

        # "EMA10_4h", "EMA20_4h", "EMA50_4h", "RSI_4h", "ATR_4h", "WILLR_4h", "BBANDS_4h", "MACD_4h", "MACD_Signal_4h",
        # "MACD_hist_4h", "OBV_4h",

        #"position", "profit", "open_radio", "empty_time", "holding_time"

    ]


    FEATURES1 = [
        "open", "high", "low", "close", "volume",
        "timestamp", "asset",
        #"open_5m", "high_5m", "low_5m",
        "close_5m", "volume_5m",

        "EMA3_5m",  "RSI_5m", "WILLR_5m", "BBANDS_5m","MACD_5m","OBV_5m",
        "price_change_pct_1bar_raw","close_raw_ema10_distance_pct",
        "MACD_Signal_5m","MACD_hist_5m","KDJ_5m",
        "ADX_5m","ATR_RADIO_5m","CROSS_RSI_WILL_5m",



        #"EMA10_1h", "EMA20_1h",  "RSI_1h", "ATR_1h", "WILLR_1h",  "MACD_1h", "MACD_Signal_1h",

        #"EMA10_4h", "EMA20_4h", "EMA50_4h", "RSI_4h", "ATR_4h", "WILLR_4h", "BBANDS_4h", "MACD_4h", "MACD_Signal_4h",
        #"MACD_hist_4h", "OBV_4h",



        "position", "profit", "open_radio", "empty_time", "holding_time"

    ]



    ASSET=["btc","eth","ltc","doge","xrp","ada"]
    #ASSET = ["btc"]


    CUT_LENGTH = 241  # 去除前面因指标计算导致的 NaN
    WINDOW_SIZE = 120  # 观测序列长度
    RANDOM_DATA=False
    SIZE_OF_TRAIN_DATA = 0
    #SIZE_OF_TRAIN_DATA = 98653
    JUMP_STEP = 1

    # ========== 风控/奖励相关 ==========
    MAX_POS_TIMES=4
    DIR_STR=0.1
    ACT_UP=0.2
    ACT_DOWN=-0.7

    RISK_STOP_LOSS = 10     # 动态止损系数 (2.0 * ATR)
    RISK_STOP_WIN = 15
    REWARD_SCALING = 1         # 1%收益 -> 1 reward
    MAX_DRAWDOWN_PENALTY = 0.5     # 回撤>20%时, 奖励减半
    RISK_PER_TRADE = 1
    MAX_DRAWDOWN_THRESHOLD = 0.2
    REWARD_RADIO = 1
    OPEN_RIGHT=0.01
    CLOSE_GAP = 5
    CLOSE_GAP_PAN = 0.01
    HOLD_TIME=40
    EMPTY_TIME=100
    MIN_HOLD=10
    MIN_EMPTY=10
    MAX_HOLD=30
    MAX_EMPTY=30
    MAX_STEPS=20

    # ========== 训练超参 ==========
    THREAD_NUM=8
    PROC_SIZE = 5e4
    BASE_LR= 8e-5
    ADAPTER_LR=2e-5
    POLICY_LR=1e-4
    VALUES_LR=1e-3
    BATCH_SIZE = 800
    ACC_STEP=4
    EPOCHS = 100
    PPO_STEPS = 600
    PPO_EPOCHS = 5
    GAMMA = 0.99
    LAMBDA = 0.95
    EPS_CLIP = 0.15
    #ENTROPY_COEF = 0.005
    TIME_COEF = 1

    ENTROPY_COEF = 0.01
    L2_COEF=0.005
    VALUE_LOSS_COEF = 1
    POLICY_LOSS =0.05
    MAX_GRAD_NORM = 1
    GRAD_NORM_WARNING_THRESHOLD = 1e6
    BEST_MODEL_PATH = "best_model.pth"
    BEST_MODEL_FN_PATH = "best_model_fn.pth"
    PRE_TRADEL_PATH = "pre_trade.pth"
    FINAL_TRADEL_PATH = "final_trade.pth"
    LONG_PATH="best_long.pth"
    SHORT_PATH = "best_short.pth"
    LONG_PATH_DR = "../best_long.pth"
    SHORT_PATH_DR = "../best_short.pth"
    TRAINTYPE="base"
    #TRAINTYPE = "adapter"
    #TRAINTYPE="final"
    # ========== 交易相关参数 ==========
    INITIAL_BALANCE = 10000.0
    TRANSACTION_FEE = 0.0005   # 手续费
    TRANSACTION_PER=1000
    VALID_ACTIONS = [

        [0, 0, 1,1],  # 持有和卖出有效 position = 1
        [1, 1, 0,0],  # 买入和空仓有效 position = 0

    ]
    VALID_ACTIONS = torch.tensor(VALID_ACTIONS, dtype=torch.float32).to(DEVICE)

    # 当回撤>20% -> 惩罚

    # ========== TFT 超参 ==========
    TFT_INPUT_SIZE = len(FEATURES)
    TFT_HIDDEN_SIZE_MARKET = 256
    TFT_HIDDEN_SIZE_POSITION=128

    TFT_NUM_HEADS = 4
    TFT_NUM_LAYERS = 8
    TFT_DROPOUT = 0.3
    EWC_LAMBDA = 1e-1  # 初始值，根据任务调整
    TFT_WINDOWS = 50
    TFT_SPARKS = 4
    NEW_API="af7b1b643a514aeab1f0b89aee2b6cfb"
    EALRY_LEARING=500000
    EARLY_STOPPING=False

