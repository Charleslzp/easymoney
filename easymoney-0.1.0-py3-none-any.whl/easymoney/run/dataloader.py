# data_init.py
import json
import pandas as pd
import numpy as np
from multiprocessing import shared_memory
from easymoney.run.configs import Config
import subprocess




def load_shared_array(meta):
    shm = shared_memory.SharedMemory(name=meta["name"])
    arr = np.ndarray(meta["shape"], dtype=np.float32, buffer=shm.buf)
    return arr, shm


def get_satart(total,begin,end):
    stage=4
    dataset_index = np.random.randint(0, stage)

    dataset_begin= dataset_index / stage * total

    data_range = int(1/stage * total)


    start=dataset_begin+(begin*data_range)
    end_index=dataset_begin+(end*data_range) -  Config.PPO_STEPS+Config.WINDOW_SIZE+1
    #print(f'start is {start} endi is {end_index} data_range is {data_range}')

    data_begin = np.random.randint(start,end_index )
    return data_begin

def init_dadabuffer_shared():
    """
    将多个 CSV 加载为 numpy，并写入共享内存。
    返回包含每个共享内存的信息的元数据列表。
    """
    shm_meta = []
    #print(Config.ASSETS_PATH)

    with open(Config.ASSETS_PATH, 'r') as file:

        datalist = json.load(file)

    for idx, filename in enumerate(datalist):
        df = pd.read_csv(f'easymoney/data/result/{filename}.csv')
        df = df[Config.FEATURES]  # 只保留指定特征列
        df['timestamp'] = pd.to_datetime(df['timestamp']).astype('int64') / 1e9  # 秒为单位
        df['timestamp'] = df['timestamp'].astype(np.float32)
        if df.isna().any().any():
            print("Data contains NaN values.")
        else:
            print("No NaN values found.")

        print(f"[INIT] datalen={len(df)} | index={idx} | name={filename}")

        arr = df.astype(np.float32).to_numpy()
        shape, dtype = arr.shape, arr.dtype

        shm = shared_memory.SharedMemory(create=True, size=arr.nbytes)
        shm_arr = np.ndarray(shape, dtype=dtype, buffer=shm.buf)
        np.copyto(shm_arr, arr)

        shm_meta.append({
            "name": shm.name,
            "shape": shape,
            "dtype": str(dtype),
            "index": idx,
            "columns": df.columns.tolist()
        })

    return shm_meta

def clear_shared_memory():
    try:
        # 执行 rm /dev/shm/* 命令来清理共享内存
        subprocess.run(['rm', '-rf', '/dev/shm/*'], check=True)
        print("Shared memory cleared successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error clearing shared memory: {e}")