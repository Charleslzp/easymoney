import talib
import numpy as np







close = [0.4291, 0.4279, 0.4265, 0.4258, 0.4255, 0.4251, 0.4258, 0.4262, 0.4259, 0.4259, 0.4259, 0.4258, 0.4265, 0.4265, 0.4266, 0.4274, 0.4268, 0.4257, 0.426, 0.4266, 0.4273, 0.4274, 0.4274, 0.4271, 0.4277]
close_array = np.array(close)

low = [
    0.4286, 0.4274, 0.4256, 0.4254, 0.4251, 0.4248, 0.4252, 0.4255, 0.4255,
    0.4254, 0.4257, 0.4256, 0.4257, 0.426, 0.4265, 0.4265, 0.4267, 0.4257,
    0.4256, 0.4261, 0.4266, 0.4272, 0.427, 0.4271, 0.4268
]
low_array = np.array(low)


high = [
    0.4293, 0.4292, 0.4286, 0.4266, 0.4267, 0.4265, 0.4263, 0.4262, 0.4262,
    0.4261, 0.4262, 0.4269, 0.4265, 0.4267, 0.4269, 0.4274, 0.4275, 0.427,
    0.4262, 0.4268, 0.4273, 0.4275, 0.4275, 0.4275, 0.4277
]
high_array = np.array(high)


willr = talib.WILLR(high_array, low_array, close_array, timeperiod=14)

print(willr[-1])

x=1 - (willr[-1] / -50)
print(x)

import torch
import torch.nn.functional as F

# 定义输入值
input_tensor = torch.tensor([1.0906721353530884, -3.233752727508545, 1.7250616550445557])

# 计算softmax
softmax_output = F.softmax(input_tensor, dim=0)

# 输出最大值的索引
print("Softmax Output:", softmax_output)

softmax_output.argmax()
