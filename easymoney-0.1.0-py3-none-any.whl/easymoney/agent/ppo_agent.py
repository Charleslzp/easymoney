import torch
import torch.nn as nn
import torch.optim as optim
from easymoney.run.configs import Config
from easymoney.model.tft_model import EasyMoneyModel

import time
from torch.cuda.amp import GradScaler
from torch.optim.lr_scheduler import LambdaLR

torch.autograd.set_detect_anomaly(True)
torch.set_printoptions(profile="full")



import math
def lr_schedule(step):
    warmup_steps = 1000
    total_steps = 100_000

    if step < warmup_steps:
        return step / warmup_steps
    else:
        progress = (step - warmup_steps) / (total_steps - warmup_steps)
        return 0.5 * (1 + math.cos(math.pi * progress))

def update_selected_probs(mask, group_probs, acts, selected_probs, action_mapping):
    """
    更新 selected_probs, 根据 action_mapping 提供的索引映射
    """
    idx = acts[mask]
    pos = torch.zeros_like(idx)

    # 根据 action_mapping 动态计算对应的索引
    for action, index in action_mapping.items():
        pos[idx == action] = index

    selected_probs[mask] = group_probs[mask, pos]

def process_actions_softmax(logits, acts):
    B = logits.size(0)

    # 创建全 -inf 的 logits 张量
    group_logits = torch.full((B, 3), float('-inf'), device=logits.device, dtype=logits.dtype)

    # 对于动作 0 和 2（开仓和加仓），在 group_logits 中设置值
    mask_A = (acts == 0) | (acts == 2)
    if mask_A.any():
        group_logits[mask_A, 0] = logits[mask_A, 0]  # 动作 0 对应索引 0
        group_logits[mask_A, 1] = logits[mask_A, 2]  # 动作 2 对应索引 1

    # 对于动作 1、3 和 4（平仓和加仓），在 group_logits 中设置值
    mask_B = (acts == 1) | (acts == 3) | (acts == 4)
    if mask_B.any():
        group_logits[mask_B, 0] = logits[mask_B, 1]  # 动作 1 对应索引 0
        group_logits[mask_B, 1] = logits[mask_B, 3]  # 动作 3 对应索引 1
        group_logits[mask_B, 2] = logits[mask_B, 4]  # 动作 4 对应索引 2

    # 替换全 -inf 行


    # 计算 softmax 概率
    group_probs = F.softmax(group_logits, dim=-1)
    eps = 1e-10
    entropy = - (group_probs * (group_probs + eps).log()).sum(dim=-1).mean()

    # 初始化 selected_probs
    selected_probs = torch.zeros(B, device=logits.device, dtype=logits.dtype)

    # 定义 action 的映射，动作 0 和 2 竞争，动作 1、3、4 竞争
    action_mapping_A = {0: 0, 2: 1}  # 动作 0 对应索引 0，动作 2 对应索引 1
    action_mapping_B = {1: 0, 3: 1, 4: 2}  # 动作 1 对应索引 0，动作 3 对应索引 1，动作 4 对应索引 2

    # 更新 selected_probs
    update_selected_probs(mask_A, group_probs, acts, selected_probs, action_mapping_A)
    update_selected_probs(mask_B, group_probs, acts, selected_probs, action_mapping_B)

    return selected_probs, entropy


def check_tensor_nan(tensor, name="tensor"):
    if torch.isnan(tensor).any():
        print(f"🚨 NaN detected in {name}")



#from torch.amp import GradScaler

from easymoney.agent.diag import diagtools
from collections import defaultdict


import pandas as pd
import torch
import torch.nn.functional as F

import torch
import torch.nn.functional as F


def get_prob(logit,act,uper=Config.ACT_UP,downer=-Config.ACT_UP):
    act_score = logit.squeeze(-1)

    # 各行为的概率（sigmoid后+归一化处理）
    buy_prob = torch.sigmoid((act_score - uper) * 5)  # 越大越偏买入
    sell_prob = torch.sigmoid((-act_score + abs(downer)) * 5)  # 越小越偏卖出
    stay_prob = 1.0 - torch.abs(torch.tanh(act_score))  # 越接近0越偏无动作

    # 归一化
    total = buy_prob + sell_prob + stay_prob + 1e-8
    buy_prob = buy_prob / total
    sell_prob = sell_prob / total
    stay_prob = stay_prob / total

    # [B, 3] 拼接
    prob_stack = torch.stack([stay_prob, buy_prob, sell_prob], dim=-1)  # [B, 3]

    # 映射动作到索引：0→stay(0)，1/2→buy(1)，3/4→sell(2)
    index = torch.zeros_like(act)
    index[(act == 1) | (act == 2)] = 1
    index[(act == 3) | (act == 4)] = 2

    # 选取对应概率
    prob = torch.gather(prob_stack, dim=1, index=index.unsqueeze(-1)).squeeze(-1)  # [B]

    return prob  # 每个样本的对应动作的概率值





class PPOAgent:
    def __init__(self, action_dim,id=0,type='gpu'):
        self.type=type
        self.gamma = Config.GAMMA
        self.lambd = Config.LAMBDA
        self.eps_clip = Config.EPS_CLIP
        self.entropy_coef = Config.ENTROPY_COEF
        self.value_loss_coef = Config.VALUE_LOSS_COEF
        self.max_grad_norm = Config.MAX_GRAD_NORM
        self.time_loss_conf=Config.TIME_COEF
        self.bestmodel=-100
        self.baseinit = False
        self.gradlist= {feature: 0 for feature in Config.FEATURES}
        self.need_clip = True
        self.train_round=0
        self.bestbacktest=-10000.0
        self.reload_time=0
        self.need_docter = False
        self.current_dim=16
        self.device = self.get_device(id)
        #self.kf=KalmanFilter()

        #self.writer = SummaryWriter(log_dir=Config.SUM_WRITER)


        """

        self.model =EnhancedStrategicTFT(
            hidden_size=Config.TFT_HIDDEN_SIZE_MARKET,
            lstm_layers=Config.TFT_NUM_LAYERS,
            dropout=Config.TFT_DROPOUT,
            attention_head_size=Config.TFT_NUM_HEADS,
            hidden_continuous_size=Config.TFT_HIDDEN_SIZE_POSITION)
        """
        self.model = EasyMoneyModel(
            input_dim=len(Config.FEATURES)-7,
            hidden_dim_market=Config.TFT_HIDDEN_SIZE_MARKET,
            hidden_dim_pos=Config.TFT_HIDDEN_SIZE_POSITION,
            num_heads=Config.TFT_NUM_HEADS,
            num_layers=Config.TFT_NUM_LAYERS,
            dropout=Config.TFT_DROPOUT,
            maxlen=Config.WINDOW_SIZE,
            num_assets=100
        )



        self.optimizer_policy = optim.Adam(self.model.parameters(), lr=Config.POLICY_LR)
        self.optimizer_values = optim.Adam(self.model.parameters(), lr=Config.VALUES_LR)
        self.optimizer_dir = optim.Adam(self.model.parameters(), lr=Config.POLICY_LR)
        self.scheduler_policy = LambdaLR(self.optimizer_policy, lr_lambda=lr_schedule)
        self.scheduler_values = LambdaLR(self.optimizer_values, lr_lambda=lr_schedule)
        self.scheduler_dir = LambdaLR(self.optimizer_dir, lr_lambda=lr_schedule)

        #self.scheduler = StepLR(self.optimizer, step_size=10, gamma=0.993)

        self.scaler = GradScaler()

        self.init_moreGPUS()

        if torch.cuda.device_count() > 1 and Config.NEED_MOREGPU == True:

            self.dr = diagtools(self.model.module)  # 可选: 加
        else:
            self.dr=diagtools(self.model)

    def get_device(self,id):
        # device_id = random.choice([0, 1])  # 假设你有两个GPU

        if self.type=='gpu':
            torch.cuda.set_device(id)  # 设置当前进程使用的GPU
            device = torch.device(f'cuda:{id}' if torch.cuda.is_available() else 'cpu')
        else:
            device = 'cpu'
        return device



    def elastic_net_loss(self,mode='all'):
        model = self.model.module if hasattr(self.model, 'module') else self.model

        # 动态调整系数（建议范围）
        base_lambda = 1.0 / ((self.train_round + 1000) ** 0.5)
        factor=((self.train_round//100000)+1)/10
        base_lambda=factor*base_lambda

        # 分层系数配置
        layer_factors = {
            'posencoder': 0.001,  # 位置编码层极弱正则
            'market_encoder': 0.01,  # 编码层弱正则
            'policy_head': 0.1,  # 策略头中等
            'values_head': 0.1,  # 值函数头中等
            'output': 0.3,  # 输出层较强（但降低原强度）
            'default': 0.5  # 其余层默认系数（原1.0过大）
        }

        l1_loss, l2_loss = 0, 0
        for name, param in model.named_parameters():
            if not param.requires_grad:
                continue

            if mode == 'policy' and 'values_head' in name:
                continue

            if mode == 'value' and 'policy_head' in name:
                continue

            # 获取层系数
            factor = next((v for k, v in layer_factors.items() if k in name), layer_factors['default'])

            # 分离参数类型
            if 'bias' in name:
                reg_strength = 0.01 * base_lambda  # bias弱正则
            elif param.dim() == 1:
                reg_strength = 0.1 * base_lambda  # 1D参数中等
            else:
                reg_strength = base_lambda  # 权重矩阵强正则

            lambda1 = base_lambda * factor
            lambda2 = 0.01 * base_lambda * factor  # L2系数设为L1的1%
            l1_loss += lambda1 * torch.norm(param, 1)
            l2_loss += lambda2 * torch.norm(param, 2)

        return l1_loss + l2_loss
    def see_doctor(self):
        print(f'检查参数分布：')
        self.dr.print_parameter_distribution()
        print(f'协方差检验：')
        self.dr.print_gradient_flow()
        print(f'梯度检验：')
        ret = self.dr.analyze_gradients()
        #if ret == 1:

        #    torch.nn.utils.clip_grad_norm_(self.model.parameters(), 0.1)
        #self.dr.debug_regularization()


    def init_moreGPUS(self):
        if torch.cuda.device_count() > 1 and Config.NEED_MOREGPU == True:
            print(f"Using {torch.cuda.device_count()} GPUs!")
            #self.model = nn.DataParallel(self.model)
            self.model = nn.DataParallel(self.model)
            #self.model = nn.DataParallel(self.model, device_ids=[0])  # 仅在GPU0上使用
            self.model = self.model.to("cuda")
        else:
            self.model = self.model.to(Config.DEVICE)



    def keep_stable(self):
        safe = True
        GRAD_NORM_WARNING_THRESHOLD = Config.GRAD_NORM_WARNING_THRESHOLD  # 超过该阈值触发警告

        # 裁剪总梯度
        total_norm=0
        if torch.cuda.device_count() > 1 and Config.NEED_MOREGPU == True:
            params = self.model.module
        else:
            params = self.model

        if self.need_clip == True :
            total_norm = torch.nn.utils.clip_grad_norm_(params.parameters(), self.max_grad_norm)

        # 检查是否超过阈值
        if total_norm > GRAD_NORM_WARNING_THRESHOLD:
            print(f"[警告] 梯度范数异常: {total_norm:.2f} (阈值={GRAD_NORM_WARNING_THRESHOLD})")
            for name, param in params.named_parameters():
                if param.grad is not None:
                    print(f"Layer: {name} | Grad Norm: {param.grad.norm().item():.2f}")
            #torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
            safe = False  # 标记为不安全

    def get_policy_loss(self, old_prob, new_prob, advantages, clib=Config.EPS_CLIP):
        """
        计算PPO的策略损失，使用剪切损失函数来限制策略更新的幅度。
        并且将动作值限制在指定的范围 [lower_limit, upper_limit]。

        参数:
        - old_prob: 旧的logits（每个动作的logit）
        - new_prob: 新的logits（每个动作的logit）
        - advantages: 计算的优势（Advantage）
        - clib: 剪切的参数 epsilon，用于限制策略更新幅度
        - lower_limit: 动作值的下限
        - upper_limit: 动作值的上限

        返回:
        - 策略损失
        """
        ratio = new_prob / (old_prob + 1e-8)

        # PPO clipping
        unclipped = ratio * advantages
        clipped = torch.clamp(ratio, 1 - clib, 1 + clib) * advantages

        loss = -torch.min(unclipped, clipped).mean()

        # 返回负损失（PPO是最小化损失，所以需要负号）
        return loss

    def check_adv(self,act,adv):
        for action in [2, 3, 4,5,6,7]:
            mask = act == action
            if mask.sum() == 0:
                continue
            advantages = adv[mask]
            print(f"动作 {action}: count={mask.sum().item()} | mean={advantages.mean():.4f} | max={advantages.max():.4f} |min={advantages.min():.4f} |"
                  f"std={advantages.std():.4f} | >0 ratio={(advantages > 0).float().mean():.2%}")

    def update(self, Traj):
        if self.model.need_frozen != True and self.train_round>2000000:
            print(f'dong jie cg')
            self.model.frozen()
        # print('dzl')
        act_adv = [item["act_adv"] for item in Traj]
        #dir_adv = [item["dir_adv"] for item in Traj]
        datas = [item["data"] for item in Traj]  # 假设这是numpy数组的列表
        acts = [item["action"] for item in Traj]
        returns = [item["returns"] for item in Traj]
        old_prob = [item["logit"] for item in Traj]
        vol = [item["vol"] for item in Traj]
        total_len=len(act_adv)
        # key_act= [item[5] for item in Traj]
        time1 = time.time()

        data_tensor = self.model.merge_dict_list_correctly(datas, self.device)
        time2 = time.time()


        # 关键修改：确保所有数据先转换为Tensor
        act_tensor = torch.tensor(acts, dtype=torch.long).to(self.device)
        act_advantages = torch.tensor(act_adv, dtype=torch.float32).to(self.device)
        vol_tensor = torch.tensor(vol, dtype=torch.float32).to(self.device)
        mean = act_advantages.mean()
        std = act_advantages.std(unbiased=False) + 1e-8
        scale = 1.0 / std.clamp(min=0.1)



        act_advantages = (act_advantages ) * scale
        #print(f'adv is {act_advantages}')

        # 进一步 clip，避免极端梯度
        act_advantages = act_advantages.clamp(min=-5.0, max=5.0)
        #act_advantages = (act_advantages - act_advantages.mean()) / (act_advantages.std() + 1e-8)
        #act_advantages = torch.clamp(act_advantages, -2, 2)
        std_adv=act_advantages.std()
        min_adv=act_advantages.min()
        max_adv=act_advantages.max()

        long_ids = [2, 3, 4]
        short_ids = [5, 6, 7]

        total = act_tensor.shape[0]

        long_count = sum((act_tensor == i).sum().item() for i in long_ids)
        short_count = sum((act_tensor == i).sum().item() for i in short_ids)

        long_ratio = long_count / total
        short_ratio = short_count / total
        direction_penalty = abs(long_ratio - short_ratio)
        λ = 0.1  # 你可以调节这个系数


        print(f'adv mean is {act_advantages.mean()},std is {std_adv},min is {min_adv},max is {max_adv}')

        
        #if std_adv<0.16 :
        ##    act_advantages= (act_advantages - act_advantages.mean()) / (act_advantages.std() + 1e-8)
        #    act_advantages = torch.clamp(act_advantages, -4, 4)
        #    print(f'new adv mean is {act_advantages.mean()},std is {act_advantages.std()},min is {act_advantages.min()},max is {act_advantages.max()}')

#        dir_advantages = torch.tensor(dir_adv, dtype=torch.float32).to(self.device)
        self.check_adv(act_tensor,act_advantages)
        #print(dir_advantages)
        returns_t = torch.tensor(returns, dtype=torch.float32).to(self.device)
        old_prob_t = torch.tensor(old_prob, dtype=torch.float32).to(self.device)

        #print(f'act_advantages is {act_advantages}')
        #print(f'act is {act_tensor}')

        #print(f'old prob is {old_prob_t}')
        #print(f'adv  is {act_advantages}')
        # print(act_tensor)
        best_avc = 1000000
        best_weights_value = None
        best_weights_policy = None
        best_weights_dir = None

        ###

        """
        for x in range(3):
            new_logit, values, dir = self.model(data_tensor)
            # print(f'values shape is {values.shape}')
            # print(f'returns_t shape is {returns_t.shape}')
            dir_loss = F.mse_loss(dir.squeeze(), dir_advantages)


            print(
                f'dir epo is {x}     drl is {dir_loss:.4f}     ', )
            self.optimizer_dir.zero_grad(set_to_none=True)
            dir_loss.backward()
            # print(f'prob grad {new_logit_t.grad}')

            # open_grad=self.model.policy_head.action[0].weight.grad
            # print(f'  grad max is {open_grad.max()} min is {open_grad.min()} mean is {open_grad.mean()}')

            self.keep_stable()
            self.optimizer_dir.step()
            self.scheduler_dir.step()"""


        best_avc = 1000000
        if  Config.Single_Value==True:
            for x in range(3) :
                new_logit, values, dir = self.model(data_tensor)
                #print(f'values shape is {values.shape}')
                #print(f'returns_t shape is {returns_t.shape}')
                value_loss = F.mse_loss(values.squeeze(), returns_t)
                #print("NaN in returns_t:", torch.isnan(returns_t).any().item())
                #print("Inf in returns_t:", torch.isinf(returns_t).any().item())


                print(
                    f'values epo is {x}     vl is {value_loss:.4f}     ', )
                self.optimizer_values.zero_grad(set_to_none=True)
                value_loss.backward()
                # print(f'prob grad {new_logit_t.grad}')


                # open_grad=self.model.policy_head.action[0].weight.grad
                # print(f'  grad max is {open_grad.max()} min is {open_grad.min()} mean is {open_grad.mean()}')

                self.keep_stable()
                self.optimizer_values.step()
                self.scheduler_values.step()

        if best_weights_value is not None:
            self.model.load_state_dict(best_weights_value)
        best_avc = 1000000

        #old_prob_f=process_actions_softmax(old_prob_t,act_tensor)
        if Config.FREEZE_POLICY!=True:
            best_weights_policy=None
            best_po=10000
            for x in range(Config.PPO_EPOCHS):

                new_logit, values, vol_pred = self.model(data_tensor)

                new_logit_f,entroloss = process_actions_softmax(new_logit.squeeze(), act_tensor)
                policy_loss = self.get_policy_loss(old_prob_t,new_logit_f, act_advantages)
                value_loss = F.mse_loss(values.squeeze(), returns_t)
                if policy_loss<best_po:
                    best_po=policy_loss
                    best_weights_policy=self.model.state_dict()
                    print(
                        f'  pll is {policy_loss:.4f}    entroloss is {entroloss}  value_loss is {value_loss}', )

                open_mask = ((act_tensor == 2) | (act_tensor == 3)).float()  # (batch,)
                # 如果 vol_pred 是 (batch,1) -> squeeze
                vol_pred_s = vol_pred.squeeze()
                # per-sample mse
                raw_vol_loss = F.mse_loss(vol_pred_s, vol_tensor, reduction="none")  # (batch,)
                # 只在开仓样本上求和并除以开仓样本数
                eps = 1e-6
                vol_count = open_mask.sum()
                vol_loss = (raw_vol_loss * open_mask).sum() / (vol_count + eps)

                ent = entroloss + 1e-6  # 防止除零
                ra = (1.2 / ent) ** 2
                ra = min(max(ra, 0.01), 0.1)  # 限制在 [0.01, 0.2] 范围内
                ra=0.1

                #total_loss=policy_loss-ra*entroloss+value_loss+ λ * direction_penalty
                lambda_vol = 0.1
                total_loss = policy_loss - ra * entroloss + value_loss + lambda_vol * vol_loss
                #total_loss = policy_loss
                # print(
                #    f'epo is {x}   avc  {right_radio:.4f} enl 1s {entroloss:.4f} pll is {policy_loss:.4f} l12 is {l12_loss:.4f}  max is {max_prob:.2f}  ', )
                # if right_radio==0.0:
                #    print(f'adv is {advantages}')
                #    print(f'logit is {new_logit_t}')

                    # print(
                    # f'epo is {x}   avc  {right_radio:.4f} enl 1s {entroloss:.4f} pll is {policy_loss:.4f} l12 is {l12_loss:.4f}  max is {max_prob:.2f}  ', )



                    # print(
                    #    f'epo is {x}   avc  {right_radio:.4f} enl 1s {entroloss:.4f} pll is {policy_loss:.4f} l12 is {l12_loss:.4f}  max is {max_prob:.2f}  ', )

                # total_plicy_loss = policy_loss  + l12_loss - entroloss

                self.optimizer_policy.zero_grad(set_to_none=True)
                total_loss.backward()
                # print(f'prob grad {new_logit_t.grad}')

                if self.need_docter == True:
                    self.see_doctor()
                    self.need_docter = False
                # open_grad=self.model.policy_head.action[0].weight.grad
                # print(f'  grad max is {open_grad.max()} min is {open_grad.min()} mean is {open_grad.mean()}')

                self.keep_stable()
                self.optimizer_policy.step()
                self.scheduler_policy.step()

            # del new_logit

        # good_act= (new_logit_t>0.5)
        # bad_act = (new_logit_t < 0.5)
        if best_weights_policy is not None:
            self.model.load_state_dict(best_weights_policy)

        del data_tensor, act_tensor

        del best_weights_policy,best_weights_value

        # if best_index != 0:
        time4 = time.time()

        time5 = time.time()
        # print(f'p4 is {time5-time4} p3 is {time4 - time3} p2 is {time3-time2} p1 is {time2-time1}')

        self.train_round += total_len

        torch.cuda.empty_cache()

        # if len(index_list)!=0:
        #    return index_list
        # else:
        return None
    def save_model(self, path):
        #save_path = f"ppo_model_ep{epoch}.pth"
        if Config.NEED_MOREGPU == True:
            torch.save({
                "model": self.model.module.state_dict(),
                "optim_policy": self.optimizer_policy.state_dict(),
                "optim_values": self.optimizer_values.state_dict(),                "best": self.bestmodel,
                "ewc_manager": self.ewc_manager,
                "baseinit":self.baseinit,
                "train_round": self.train_round,
                "bestbacktest": self.bestbacktest,
                "current_dim": self.current_dim
            }, path)
        else:
            torch.save({
                "model": self.model.state_dict(),
                "optim_policy": self.optimizer_policy.state_dict(),
                "optim_values": self.optimizer_values.state_dict(),
                "best": self.bestmodel,
                "baseinit": self.baseinit,
                "train_round": self.train_round,
                "bestbacktest":self.bestbacktest,
                "current_dim":self.current_dim
            }, path)
        print(f"Model saved at {path}")

    def load_model(self, path=None):
        if path is None:
            print("No model path specified, training from scratch.")
            return
        import os
        if os.path.exists(path):
            #print(f'path is {path}')
            data = torch.load(path, map_location=self.device, weights_only=False)
            if Config.NEED_MOREGPU == True:
                self.model.module.load_state_dict(data["model"])
            else:
                self.model.load_state_dict(data["model"])
            self.optimizer_policy.load_state_dict(data["optim_policy"]),
            self.optimizer_values.load_state_dict(data["optim_values"]),
            self.bestmodel = data["best"]
            self.baseinit = data["baseinit"]
            self.train_round = data["train_round"]
            self.bestbacktest = data["bestbacktest"]
            self.current_dim=data["current_dim"]

            params = sum(p.numel() for p in self.model.parameters())
            print(f"Loaded model from {path}, steps {data.get('train_round', -1)}  总参数量: {params / 1e6:.2f}M")



            if self.baseinit == True:
                print('load init is True')
                """
                if Config.NEED_MOREGPU == True:
                    self.model.module._freeze_base()
                else:

                    self.model._freeze_base()
                    """

        else:
            print(f"Model file not found: {path}, training from scratch.")

