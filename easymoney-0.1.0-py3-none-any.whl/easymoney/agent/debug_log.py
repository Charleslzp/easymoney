import torch
import pandas as pd


def write_time_log(train_round,state_t,returns_t_time,gae_time,tar_time_t,real_time_t):
    filename = f"./logs/time_{train_round}.csv"
    #print(f"shape of state_t  {state_t[:,-1,-2:].shape}")
    #print(f"shape of returns_t_time  {returns_t_time.shape}")
    #print(f"shape of gae_time  {gae_time.shape}")
    #print(f"shape of tar_time_t  {tar_time_t.shape}")
    #print(f"shape of real_time_t  {state_t[:, -1, -5].shape}")
    combied = torch.cat([
            state_t[:,-1,-2:] ,  #用于决策的时间
            returns_t_time.unsqueeze(1),  # GAE算出来的时间
            gae_time.unsqueeze(1),   # 时间的优势
            tar_time_t.unsqueeze(1),  # 原始预测值
            real_time_t.unsqueeze(1), #实际的奖励
            state_t[:, -1, -5].unsqueeze(1),
            state_t[:, -1, -3].unsqueeze(1),

        ], dim=-1)

    df = pd.DataFrame(combied.cpu().numpy(),columns=["empty", "hold","GAE_RETURN","GAE","PREDICT","REAL_TIME","position","act"])
    df.to_csv(filename, index=False)  # 不保存索引