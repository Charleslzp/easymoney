import torch
import numpy as np
import torch.nn as nn
import csv


torch.autograd.set_detect_anomaly(True)



def check_model_state(model):
    if not isinstance(model, nn.Module):
        raise TypeError(f"模型类型错误: 预期 nn.Module, 实际 {type(model)}")

    if len(list(model.children())) == 0:
        raise ValueError("模型未包含任何子模块")

    if sum(p.numel() for p in model.parameters()) == 0:
        raise ValueError("模型未包含任何可训练参数")

def auto_fix_initialization(model):
    for name, param in model.named_parameters():
        if 'weight' in name:
            if param.dim() > 1:  # 矩阵权重
                nn.init.kaiming_normal_(param, mode='fan_in', nonlinearity='relu')
            else:  # 向量权重
                nn.init.normal_(param, mean=0.0, std=0.02)
        elif 'bias' in name:
            nn.init.constant_(param, 0.0)
def replace_relu_with_leaky(model):
    check_model_state(model)

    # 遍历所有子模块
    for name, module in model.named_modules():
        if isinstance(module, nn.ReLU):
            # 获取父模块和子模块名称
            parent_name = name.rsplit('.', 1)[0] if '.' in name else ''
            child_name = name.split('.')[-1]

            # 获取父模块
            parent = model
            if parent_name:
                for part in parent_name.split('.'):
                    parent = getattr(parent, part)

            # 替换激活函数
            setattr(parent, child_name, nn.LeakyReLU(negative_slope=0.01))
            print(f"已替换: {name} -> LeakyReLU")

def check_gradient_existence(model):
    has_grad = [p.grad is not None for p in model.parameters()]
    #print(f"有梯度的参数: {sum(has_grad)}/{len(has_grad)}")
    if sum(has_grad) == 0:
        raise RuntimeError("未检测到有效梯度，请检查反向传播流程")


def filter_problematic_layers(layer_grads):
    problems = []

    for layer_name, grads in layer_grads.items():
        if len(grads) < 2:
            continue  # 跳过参数不足的层

        # 计算协方差矩阵
        max_len = max(len(g) for g in grads)
        padded_grads = [np.pad(g, (0, max_len - len(g))) for g in grads]
        grad_matrix = np.vstack(padded_grads)
        grad_matrix_centered = grad_matrix - np.mean(grad_matrix, axis=1, keepdims=True)

        # 计算协方差矩阵
        cov_matrix = np.dot(grad_matrix_centered, grad_matrix_centered.T) / (grad_matrix.shape[1] - 1)

        # 添加正则化项
        epsilon = 1e-6
        cov_matrix += np.eye(cov_matrix.shape[0]) * epsilon

        try:
            # 计算条件数和秩
            cond_num = np.linalg.cond(cov_matrix)
            rank = np.linalg.matrix_rank(cov_matrix)

            # 检测问题
            if cond_num > 1e6:
                problems.append((layer_name, '协方差矩阵奇异', f'条件数: {cond_num:.2e}'))
            if rank < len(grads):
                problems.append((layer_name, '参数冗余', f'秩: {rank}/{len(grads)}'))

        except np.linalg.LinAlgError:
            # 捕获SVD计算不收敛的异常
            problems.append((layer_name, '协方差矩阵计算失败', 'SVD did not converge'))

    return problems

def get_layer_gradients(model):
    layer_grads = {}
    for name, param in model.named_parameters():
        if param.grad is not None:
            # 提取层名称 (示例: 'base_tft.layers.0.0.query' -> 'layers.0.0')
            layer_name = '.'.join(name.split('.')[:4])  # 根据实际命名调整
            grad_vec = param.grad.flatten().cpu().numpy()

            if layer_name not in layer_grads:
                layer_grads[layer_name] = []
            layer_grads[layer_name].append(grad_vec)

    return layer_grads


def filter_problematic_params(param_stats):
    problems = []

    for name, stats in param_stats.items():
        mean = stats['mean']
        std = stats['std']
        min_val = stats['min']
        max_val = stats['max']
        layer_type = stats['layer_type']
        activation_function = stats['activation_function']
        init_method = stats['init_method']


        if mean != 1.0 and (abs(mean) > 0.1 or std > 0.6):
            problems.append((name, '初始化异常', f' meanis: [{mean:.3e},std is  {std:.3e}]'))


        # 检测分布不对称
        #print(f'min_vla is {min_val}')
        max_val=abs (max_val)- 1
        min_val=abs(min_val)
        if max_val ==0 :
            nn = 0
        else :
            nn=min_val/ abs(max_val)


        if nn > 1:
            problems.append((name, '分布不对称', f'范围: [{min_val:.3e}, {max_val:.3e}]'))

        # 检测死亡神经元（针对权重）
        if 'weight' in name and abs(mean) < 1e-5:
            problems.append((name, '死亡神经元风险', f'均值: {mean:.3e}'))

    return problems


def collect_param_stats(model):
    stats = {}
    for name, param in model.named_parameters():
        # 提取数据
        data = param.detach().cpu().numpy().flatten()

        # 获取层的类型
        layer_type = None
        activation_fn = None
        init_method = None

        # 尝试获取每个参数所在层的类型和激活函数
        for name, module in model.named_modules():
            if name in name:  # 确定当前参数属于哪一层
                layer_type = type(module).__name__  # 获取层的类型
                # 检查该层的激活函数
                if isinstance(module, nn.ReLU):
                    activation_fn = 'ReLU'
                elif isinstance(module, nn.LeakyReLU):
                    activation_fn = 'LeakyReLU'
                elif isinstance(module, nn.Sigmoid):
                    activation_fn = 'Sigmoid'
                elif isinstance(module, nn.Tanh):
                    activation_fn = 'Tanh'
                elif isinstance(module, nn.Linear):
                    activation_fn = 'Linear (likely Xavier/He init)'
                break

        # 推测初始化方法（根据层类型）
        if isinstance(param, nn.Linear):
            init_method = 'Xavier/He Initialization'  # 默认认为全连接层用 Xavier 或 He 初始化
        elif isinstance(param, nn.Conv2d):
            init_method = 'Xavier Initialization'  # 卷积层常用 Xavier 初始化

        #print(f'np.min(data) is{np.min(data)}')
        # 保存统计信息
        stats[name] = {
            "mean": np.mean(data),  # 均值
            "std": np.std(data),  # 标准差
            "min": np.min(data),  # 最小值
            "max": np.max(data),  # 最大值
            "layer_type": layer_type,
            "activation_function": activation_fn,
            "init_method": init_method
        }

        #print(f'sats is {stats}')

    return stats


class diagtools:
    def __init__(self, model):
        self.model = model

    def report_problematic_layers(self):
        layer_grads = get_layer_gradients(self.model)
        problems = filter_problematic_layers(layer_grads)

        if not problems:
            print("未检测到明显问题层")
            return

        print("\n=== 问题层协方差信息报告 ===")
        print(f"{'层名称':<30} {'问题类型':<20} {'详细信息':<30}")
        print("-" * 80)
        for layer_name, issue, detail in problems:
            print(f"{layer_name:<30} {issue:<20} {detail:<30}")


    def print_gradient_flow(self):


        check_gradient_existence(self.model)
        self.report_problematic_layers()


    def print_parameter_distribution(self):
        param_stats = collect_param_stats(self.model)

        # 过滤问题参数
        problems = filter_problematic_params(param_stats)

        # 生成报告
        if not problems:
            print("未检测到明显问题参数")
            return

        print("\n=== 问题参数分布报告 ===")
        print(f"{'参数名称':<50} {'问题类型':<20} {'详细信息':<30}")
        print("-" * 100)
        for name, issue, detail in problems:
            print(f"{name:<50} {issue:<20} {detail:<30}")

    def analyze_gradients(self):
        # 收集梯度信息
        grad_norms = []
        grad_stds = []
        gradients = []
        param_names = []  # 用来存储参数名
        ret = 0

        for name, param in self.model.named_parameters():
            if param.grad is not None:
                grad = param.grad.detach().cpu().numpy().flatten()
                gradients.extend(grad)
                grad_norm = np.linalg.norm(grad)
                grad_norms.append(grad_norm)
                if len(grad)>1:
                    grad_stds.append(np.std(grad))
                param_names.append(name)  # 存储参数名

        # 全局梯度范数
        global_grad_norm = np.linalg.norm(grad_norms)
        min_grad_norm = min(grad_norms)
        max_grad_norm = max(grad_norms)

        # 参数梯度标准差
        min_grad_std = min(grad_stds)
        max_grad_std = max(grad_stds)

        # 获取对应梯度问题的参数名
        min_grad_norm_name = param_names[grad_norms.index(min_grad_norm)]
        max_grad_norm_name = param_names[grad_norms.index(max_grad_norm)]
        min_grad_std_name = param_names[grad_stds.index(min_grad_std)]
        max_grad_std_name = param_names[grad_stds.index(max_grad_std)]

        with open("gradients.csv", mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["parameter_name", "gradient_value"])
            # 遍历每个参数及其梯度
            for name, param in self.model.named_parameters():
                if param.grad is not None:
                    grad = param.grad.detach().cpu().numpy().flatten()
                    # 为每个梯度值写入一行，参数名相同
                    for value in grad:
                        writer.writerow([name, value])

        # 判断梯度状态
        if max_grad_norm > 1e6:
            print("警告：检测到梯度爆炸风险")
            print(f"全局梯度范数: {global_grad_norm:.3e}")
            print(f"最大梯度范数: {max_grad_norm:.3e}, 参数: {max_grad_norm_name}")
            print(f"最大梯度标准差: {max_grad_std:.3e}, 参数: {max_grad_std_name}")
            ret = 1

        if min_grad_std < 1e-6:
            print("警告：检测到梯度消失风险")
            print(f"最小梯度范数: {min_grad_norm:.3e}, 参数: {min_grad_norm_name}")
            print(f"最小梯度标准差: {min_grad_std:.3e}, 参数: {min_grad_std_name}")
            print(f"梯度消失比例: {sum(g < 1e-6 for g in grad_norms) / len(grad_norms):.1%}")

        return ret

    def debug_regularization(self):
        total_l1, total_l2 = 0.0, 0.0
        total_params = 0

        for name, param in self.model.named_parameters():
            if 'bias' in name or 'bn' in name:
                continue
            total_l1 += torch.norm(param, p=1).item()
            total_l2 += torch.norm(param, p=2).item()
            total_params += param.numel()

        print(f"总参数量: {total_params}")
        print(f"平均L1/参数: {total_l1 / total_params:.6f}")
        print(f"平均L2/参数: {total_l2 / total_params:.6f}")
        print(f"L1总和（未乘λ）: {total_l1:.4f}")
        print(f"L2总和（未乘λ）: {total_l2:.4f}")

