import time
import random
from easymoney.agent.ppo_agent import PPOAgent
from easymoney.run.configs import Config
import torch

import os
from collections import deque


os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "backend:native"

class history_manager:
    def __init__(self,i):
        self.history =  deque(maxlen=200)


class model_researcher:
    def __init__(self,i):
        self.agent = PPOAgent(4,0)
        self.agent.train_round=0
        self.device=Config.DEVICE

        self.id=i
        self.device = self.get_device(i)
        self.load_model()
        self.history=None
        self.traj_all=[]
        self.traj_len=0
        #self.agent.model.to(self.device)
        print(f'reserch on device id: {self.device}')

    def get_device(self,i):
        #device_id = random.choice([0, 1])  # 假设你有两个GPU
        if i in[0] :


            device_id = 0
        else :
            device_id = 1

        torch.cuda.set_device(device_id)  # 设置当前进程使用的GPU
        device = torch.device(f'cuda:{device_id}' if torch.cuda.is_available() else 'cpu')
        return device

    def load_model(self):
        if Config.TRAINTYPE == "base":
            self.agent.load_model(Config.PRE_TRADEL_PATH)
            print(f'load from base')
        else:
            import os
            if os.path.exists(Config.FINAL_TRADEL_PATH):
                self.agent.load_model(Config.FINAL_TRADEL_PATH)
                print(f'load from adapter')
            else:
                self.agent.load_model(Config.BEST_MODEL_PATH)
                #self.agent.bestmodel=-100
                print(f'load from base,because adapter is not exist')

            #self.agent.model.frozen()

        self.agent.model=self.agent.model.to(self.device)
        self.agent.device=self.device
        #self.agent.model.frozen()

    def see_doc(self,instrument):
        if not instrument.empty():
            instrument_code = instrument.get(block=False)
        else:
            return

        if instrument_code== 1 :
            self.agent.need_docter=True


def get_newmodel(model_researcher):
    if torch.cuda.device_count() > 1 and Config.NEED_MOREGPU == True:

        updata_modle = model_researcher.agent.model.module.state_dict()  # 可选: 加
    else:
        updata_modle = model_researcher.agent.model.state_dict()  # 可选: 加
    updated_params_cpu = {key: value.cpu() for key, value in updata_modle.items()}
    return updated_params_cpu





def consumer_task(producer_queue, consumer_queue, num_producers, instrument,i,stop_event):

    researcher=model_researcher(i)
    update_counter=0
    time1=time.time()
    his_len=2000
    history = deque(maxlen=his_len)

    traj_mem=[]
    totalen=0
    try:
        while not stop_event.is_set():

            researcher.see_doc(instrument)
            Traj = producer_queue.get()

            #print(f'len of Traj is {len(Traj)}')
            for i in Traj:
                traj_mem.append(i)
                if i["action"] in [2,3,4,5]:
                    history.append(i)
                #print(i[0])
                totalen+=1
                #print(f'get buffer {totalen} ')

            if len(history)>300:
                for _ in range(4):
                    temp = history.popleft()
                    traj_mem.append(temp)

                    totalen += 1



            if totalen <=  Config.BATCH_SIZE :
                continue


            #print(f'get enough data (len={len(traj_mem)}) sp is {traj_mem}')
            time_used1 = time.time() - time1
            time2=time.time()
            index=researcher.agent.update(traj_mem)
            if index != None :
                #print(f'len is {len(history)}')
                for i in traj_mem:
                    #print(f'i is {traj_mem[i]}')
                    history.append(i)


            if update_counter % 3 == 0:

                updated_params_cpu = get_newmodel(researcher)
                model_data = {}
                model_data['model'] = updated_params_cpu
                model_data['version'] = researcher.agent.train_round
                for i in range(num_producers + 1):
                    #print(f'i is{i}')
                    if not consumer_queue[i].empty():
                        rm_data = consumer_queue[i].get()
                    consumer_queue[i].put(model_data)
                update_counter = 0

            update_counter += 1

            time_used2 = time.time() - time2
            print(f'queue len is {producer_queue.qsize()}  data used time {time_used1} update used time {time_used2} ')
            #history.append(traj_mem)
            del traj_mem
            traj_mem=[]
            totalen=0
            time1 = time.time()
            # 数据加工处理（替换实际业务逻辑）
            #processed_data = f"加工后的 {data}"
            #print(f"👷♂️ 消费者处理数据: {processed_data}")
            #consumer_queue.put(processed_data)
    except KeyboardInterrupt:
        pass
    finally:
        print("🚪 消费者退出")
        consumer_queue.put(None)  # 发送结束信号
