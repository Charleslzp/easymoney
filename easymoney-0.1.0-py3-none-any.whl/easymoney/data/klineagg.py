import pandas as pd
from datetime import timedelta
from typing import Optional,Dict


class TimeAlignedBuffer:
    """时间对齐的K线缓存管理器"""

    def __init__(self, base_interval: str, target_interval: str):
        self.base_td = pd.to_timedelta(base_interval)
        self.target_td = pd.to_timedelta(target_interval)
        self.expected_bars = int(self.target_td / self.base_td)

        self.current_window_start = None
        self.current_window_end = None
        self.buffer = {
            'open': [], 'high': [], 'low': [],
            'close': [], 'volume': [], 'timestamp': []
        }

    def add_candle(self, candle: Dict) -> Optional[Dict]:
        candle_time = pd.to_datetime(candle['timestamp'])

        # 初始化第一个窗口
        if self.current_window_start is None:
            self.current_window_start = self._align_time(candle_time)
            self.current_window_end = self.current_window_start + self.target_td

        # 检查是否应该先聚合前一个窗口
        if candle_time >= self.current_window_end:
            result = self._finalize_window()  # 先聚合已完成的窗口
            self._start_new_window(candle_time)  # 再开启新窗口
            self._store_candle(candle)  # 存储当前K线（属于新窗口）
            return result

        # 正常存储当前窗口数据
        self._store_candle(candle)
        return None

    def _start_new_window(self, candle_time: pd.Timestamp):
        """启动新时间窗口"""
        self.current_window_start = self._align_time(candle_time)
        self.current_window_end = self.current_window_start + self.target_td
        self.buffer = {k: [] for k in self.buffer}

    def _align_time(self, dt: pd.Timestamp) -> pd.Timestamp:
        """严格对齐到目标周期起始时间"""
        if self.target_td >= pd.Timedelta(days=1):
            return dt.normalize()  # 对齐到当日0点
        else:
            interval_hours = self.target_td.total_seconds() // 3600
            return dt.floor(f'{int(interval_hours)}h')

    def _store_candle(self, candle: Dict):
        """存储合规数据"""
        self.buffer['open'].append(float(candle['open']))
        self.buffer['high'].append(float(candle['high']))
        self.buffer['low'].append(float(candle['low']))
        self.buffer['close'].append(float(candle['close']))
        self.buffer['volume'].append(float(candle['volume']))
        self.buffer['timestamp'].append(pd.to_datetime(candle['timestamp']))

    def _finalize_window(self) -> Optional[Dict]:
        """完成窗口处理"""
        # 检查数据完整性
        """
        if len(self.buffer['open']) != self.expected_bars:
            print(f"数据不完整: 需要{self.expected_bars}根，实际{len(self.buffer['open'])}根")
            print(f'buffersis {self.buffer}')
            self._reset_window()
            return None"""

        # 生成聚合K线
        agg_kline = {
            'open': self.buffer['open'][0],
            'high': max(self.buffer['high']),
            'low': min(self.buffer['low']),
            'close': self.buffer['close'][-1],
            'volume': sum(self.buffer['volume']),
            'start_time': self.current_window_start,
            'end_time': self.current_window_end
        }
        #print('有正常的')

        # 重置窗口
        self._reset_window()
        return agg_kline

    def _reset_window(self):
        """重置收集窗口"""
        self.current_window_start = self.current_window_end
        self.current_window_end += self.target_td
        self.buffer = {k: [] for k in self.buffer}