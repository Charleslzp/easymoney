
import pandas as pd
import torch
import numpy as np
import talib
from collections import deque
from typing import Dict, Optional
from tqdm import tqdm
from easymoney.data.klineagg import TimeAlignedBuffer
import json
import gc
#import objgraph
#from memory_profiler import profile
import sys
from pympler import asizeof
from easymoney.run.configs import Config
import torch.multiprocessing as mp
import traceback








class DynamicNormalizer:
    """动态滚动归一化器"""

    def __init__(self, window_size=1000):
        self.window = deque(maxlen=window_size)


    def update(self, value: float) -> None:

        """更新数据窗口"""
        if len(self.window)==0:
            self.window.append(value)

        elif value != self.window[-1]:
            self.window.append(value)
        #else:
        #    print('no new data')

    def normalize(self, value: float) -> Optional[float]:
        """Z-Score归一化"""
        if len(self.window) < 2:
            return None
        arr = np.array(self.window)
        mean = arr.mean()
        std = arr.std()
        if std == 0:
            return 0.0  # 已经是Python float
        else:
            # 显式转换为Python float
            normalized_value = float((value - mean) / std)
            normalized_value=max(-5, min(5, normalized_value))
            return normalized_value



class FeatureEngine:
    def __init__(self, id=0):
        self.device =f'cuda:{id}' if torch.cuda.is_available() else 'cpu'
        self.period_config = {
            '15m': {'window': 1},
            #'1h': {'window':12},
            #'4h': {'window': 48}
        }
        self.period_handlers = {
            '1h': TimeAlignedBuffer(base_interval='15m', target_interval='1h'),
            '4h': TimeAlignedBuffer(base_interval='15m', target_interval='4h')
        }
        self.history = {p:  [] for p in self.period_config}
        self.ticker1=0
        self.ticker1 = 0
        self.initticker=False
        self.gas=1
        self.count=0



        self.normalizers = {}

        for period in self.period_config:
            for feat in ['open', 'high', 'low', 'close', 'volume']:
                key = (feat, period)
                self.normalizers[key] = DynamicNormalizer(window_size=1000)

        self.ema_normalizers = {}
        for period in self.period_config:
            for feat in ['open', 'high', 'low', 'close', 'volume']:
                key = (feat, period)
                self.normalizers[key] = DynamicNormalizer(window_size=1000)

        # 指标参数配置
        """
        self.indicator_params = {
            'RSI': {'periods': [14], 'apply_to': ['5m', '1h', '4h']},
            'MACD': {'apply_to': ['5m', '1h', '4h']},
            'MACD_Signal': {'apply_to':  ['5m', '1h', '4h']},
            'MACD_hist': {'apply_to':  ['5m', '1h', '4h']},
            'BBANDS': {'apply_to':  ['5m', '1h', '4h']},
            'WILLR': {'periods': [14], 'apply_to': ['5m', '1h', '4h']},
            'OBV': {'apply_to': ['5m', '1h', '4h']},
            'EMA': {'periods': [10, 20], 'apply_to':  ['5m', '1h', '4h']},
            'ATR': {'periods': [14], 'apply_to':  ['5m', '1h', '4h']}
        }"""

        self.indicator_params = {
            'RSI': {'periods': [7], 'apply_to': ['15m']},
            'MACD': {'apply_to': ['15m']},
            'MACD_Signal': {'apply_to': ['15m']},
            'MACD_hist': {'apply_to': ['15m']},
            'BBANDS': {'apply_to': ['15m']},
            'WILLR': {'periods': [9], 'apply_to': ['15m']},
            'OBV': {'apply_to': ['15m']},
            'EMA': {'periods': [3, 10,20], 'apply_to': ['15m']},
            'ATR': {'periods': [14], 'apply_to': ['15m']},
            'ADX': {'periods': [14], 'apply_to': ['15m']},
            'KDJ': { 'apply_to': ['15m']},
        }

        for apply_to_period in self.indicator_params['EMA']['apply_to']:  # 遍历所有周期
            for period in self.indicator_params['EMA']['periods']:
                key = f"EMA{period}_{apply_to_period}"
                self.ema_normalizers[key] = DynamicNormalizer(window_size=1000)

        self.indicator_normalizers = {}
        indicators_to_normalize = ['MACD', 'MACD_Signal','MACD_hist', 'ATR','OBV']
        for indicator in indicators_to_normalize:
            for p in self.indicator_params.get(indicator, {}).get('apply_to', []):
                key = f"{indicator}_{p}"
                self.indicator_normalizers[key] = DynamicNormalizer(window_size=1000)

    #def get_device(self,id):
    #    device =

    def process(self, kline: Dict) -> Optional[Dict]:

        # 数据预处理
        try:
            processed = {
                'open': float(kline['open']),
                'high': float(kline['high']),
                'low': float(kline['low']),
                'close': float(kline['close']),
                'volume': float(kline['volume']),
                'timestamp': pd.to_datetime(kline['timestamp'])
            }
        except:
            return None

        # 更新缓冲区
        features = {}
        # features['timestamp'] = kline['timestamp']

        for period in self.period_config:
            if period == "15m":
                agg_kline = processed

                self.history[period].append(agg_kline)
                if len(self.history[period])>200:
                    self.history[period].pop(0)
            #else:

                #agg_kline = self.period_handlers[period].add_candle(processed)

                #if agg_kline is not None:
                #    self.history[period].append(agg_kline)

                # else:
                #    print('no new data for')

            if len(self.history[period]) > 0:
                latest = self.history[period][-1]

                for feat in ['open', 'high', 'low', 'close', 'volume']:
                    # 原始值
                    if period not in ["1h", "4h"]:
                        raw_value = latest[feat]
                        features[feat] = raw_value

                        key = (feat, period)

                        self.normalizers[key].update(raw_value)
                        normal_value= self.normalizers[key].normalize(raw_value)
                        # print(f'dzl')
                        features[f'{feat}_{period}'] = normal_value


        # 指标计算

        try:
            # RSI
            for p in self.indicator_params['RSI']['apply_to']:
                if len(self.history[p]) >= 21:  # RSI(14)需要至少15数据
                    close = np.array([k['close'] for k in self.history[p][-20:]], dtype=np.float64)
                    if self.gas < 2:
                        Close = close
                    else:
                        Close = talib.EMA(close, timeperiod=self.gas)
                    rsi = talib.RSI(Close, timeperiod=14)[-1].item()

                    features[f"RSI_{p}"] = (rsi / 100 - 0.5) * 2  # 归一化到[-1,1]
                    #df['price_change_pct_1bar_raw'] = df['close'].pct_change() * 100
                    norm_atr=(Close[-1] / Close[-2] - 1) * 30
                    norm_atr = max(-5, min(5, norm_atr))
                    features['price_change_pct_1bar_raw']=norm_atr
                    norm_atr = (Close[-1] / Close[-4] - 1) * 30
                    norm_atr = max(-5, min(5, norm_atr))
                    features['price_change_pct_3bar_raw'] = norm_atr
                    norm_atr = (Close[-1] / Close[-2] - 1) * 30
                    norm_atr = max(-5, min(5, norm_atr))
                    features['price_change_pct_5bar_raw'] = norm_atr
                    del rsi
                    # print(features)
                    # features[f"RSI_{p}"] =rsi
           
            # MACD
            for p in self.indicator_params['MACD']['apply_to']:
                if len(self.history[p]) >= 51:
                    close = np.array([k['close'] for k in self.history[p][-50:]], dtype=np.float64)
                    if self.gas < 2:
                        Close = close
                    else:
                        Close = talib.EMA(close, timeperiod=self.gas)
                    macd, signal, hist = talib.MACD(Close, fastperiod=12, slowperiod=26, signalperiod=9)
                    # print(hist)
                    # 转换并归一化
                    macd_val = macd[-1].item()
                    signal_val = signal[-1].item()
                    his_val = hist[-1].item()

                    # 更新归一化器
                    self.indicator_normalizers[f"MACD_{p}"].update(macd_val)
                    self.indicator_normalizers[f"MACD_Signal_{p}"].update(signal_val)
                    self.indicator_normalizers[f"MACD_hist_{p}"].update(his_val)

                    # 获取归一化值
                    norm_macd = self.indicator_normalizers[f"MACD_{p}"].normalize(macd_val)
                    norm_signal = self.indicator_normalizers[f"MACD_Signal_{p}"].normalize(signal_val)
                    norm_hist = self.indicator_normalizers[f"MACD_hist_{p}"].normalize(his_val)
                    features.update({
                        f"MACD_{p}": round(norm_macd, 8) if norm_macd else 0.0,
                        f"MACD_Signal_{p}": round(norm_signal, 8) if norm_signal else 0.0,
                        f"MACD_hist_{p}": round(norm_hist, 8) if norm_hist else 0.0
                    })
                    hist_diff1=hist[-1]-hist[-2]
                    hist_diff2 = hist[-2] - hist[-3]
                    hist_acc=hist_diff1-hist_diff2
                    features['macd_hist_slope'] = hist_diff1
                    features['macd_hist_accel'] =hist_acc

                    del macd, signal, hist

                # ATR（添加归一化）
            for p in self.indicator_params['ATR']['apply_to']:
                if len(self.history[p]) >= 21:
                    high = np.array([k['high'] for k in self.history[p][-20:]], dtype=np.float64)
                    low = np.array([k['low'] for k in self.history[p][-20:]], dtype=np.float64)
                    close = np.array([k['close'] for k in self.history[p][-20:]], dtype=np.float64)
                    if self.gas < 2:
                        Close = close
                        Low = low
                        High = high
                    else:
                        Close = talib.EMA(close, timeperiod=self.gas)
                        Low = talib.EMA(low, timeperiod=self.gas)
                        High = talib.EMA(high, timeperiod=self.gas)

                    atr_val = talib.ATR(High, Low, Close, timeperiod=14)[-1].item()

                    recent_mean_price = Close[-20:].mean()
                    atr_radio=atr_val / recent_mean_price
                    norm_atr_ratio = (atr_radio / 0.1) * 1.0
                    norm_atr_ratio = np.clip(norm_atr_ratio, -1.0, 1.0)
                    features[f"ATR_RADIO_15m"]=norm_atr_ratio*10
                    #print(f'here')

                    # 更新并归一化
                    key = f"ATR_{p}"
                    self.indicator_normalizers[key].update(atr_val)
                    norm_atr = self.indicator_normalizers[key].normalize(atr_val)

                    features[key] = round(norm_atr, 8)
                    del atr_val

            for p in self.indicator_params['OBV']['apply_to']:
                if len(self.history[p]) >= 21:

                    close = np.array([k['close'] for k in self.history[p][-20:]], dtype=np.float64)
                    volume = np.array([k['volume'] for k in self.history[p][-20:]], dtype=np.float64)
                    if self.gas < 2:
                        Close = close
                    else:
                        Close = talib.EMA(close, timeperiod=self.gas)

                    obv_raw=talib.OBV(Close, volume)
                    obv = obv_raw[-1].item()
                    # print(obv)

                    # 更新并归一化
                    key = f"OBV_{p}"
                    self.indicator_normalizers[key].update(obv)
                    norm_atr = self.indicator_normalizers[key].normalize(obv)
                    norm_atr= max(-5, min(5, norm_atr))

                    features[key] = round(norm_atr, 8)

                    del obv_raw

                    #features['obv_slope_5'] = features[key].diff(periods=5)



            # 布林带
            for p in self.indicator_params['BBANDS']['apply_to']:
                if len(self.history[p]) >= 27:  # BBANDS(20)需要至少21数据
                    close = np.array([k['close'] for k in self.history[p][-26:]], dtype=np.float64)
                    if self.gas < 2:
                        Close = close
                    else:
                        Close = talib.EMA(close, timeperiod=self.gas)
                    upper, middle, lower = talib.BBANDS(Close, timeperiod=20)
                    current_price = Close[-1]
                    # 布林带归一化
                    if current_price > upper[-1]:
                        bb_norm = 1.0
                    elif current_price < lower[-1]:
                        bb_norm = -1.0
                    else:
                        bb_norm = 2 * (current_price - middle[-1]) /( (upper[-1] - lower[-1]))
                    features[f"BBANDS_{p}"] = torch.tensor(bb_norm, device=self.device)

                    del upper,middle,lower

            # 威廉指标
            for p in self.indicator_params['WILLR']['apply_to']:
                if len(self.history[p]) >= 21:
                    high = np.array([k['high'] for k in self.history[p][-20:]], dtype=np.float64)
                    low = np.array([k['low'] for k in self.history[p][-20:]], dtype=np.float64)
                    close = np.array([k['close'] for k in self.history[p][-20:]], dtype=np.float64)
                    if self.gas < 2:
                        Close = close
                        Low = low
                        High = high
                    else:
                        Close = talib.EMA(close, timeperiod=self.gas)
                        Low = talib.EMA(low, timeperiod=self.gas)
                        High = talib.EMA(high, timeperiod=self.gas)
                    willr = talib.WILLR(High, Low, Close, timeperiod=14)
                    if len(willr) == 0:
                        willr = -50.0  # 默认中间值（对应归一化后的 0.0）
                    else:
                        willr = float(willr[-1].item())  # 双重转换

                    features[f"WILLR_{p}"] = 1 - (willr / -50)  # 转换到[-1,1]
                    # features[f"WILLR_{p}"]=willr
                    del willr
            
            #ADX
            for p in self.indicator_params['ADX']['apply_to']:
                if len(self.history[p]) >= 30:
                    high = np.array([k['high'] for k in self.history[p][-29:]], dtype=np.float64)
                    low = np.array([k['low'] for k in self.history[p][-29:]], dtype=np.float64)
                    close = np.array([k['close'] for k in self.history[p][-29:]], dtype=np.float64)
                    if self.gas < 2:
                        Close = close
                        Low = low
                        High = high
                    else:
                        Close = talib.EMA(close, timeperiod=self.gas)
                        Low = talib.EMA(low, timeperiod=self.gas)
                        High = talib.EMA(high, timeperiod=self.gas)
                    #print(f'hight is {High}')
                    #print(f'Low is {Low}')
                    #print(f'Close is {Close}')

                    ADX_ALL=talib.ADX(High, Low,Close, timeperiod=14)
                    adx_v=ADX_ALL[-1]
                    #print(f'adx_v is {ADX_ALL}')
                    if adx_v>25:
                        adx_f= (adx_v-25)/75
                    else:
                        adx_f=-(adx_v)/100
                    norm_adx = np.clip(adx_f, -1.0, 1.0)
                    features[f"ADX_{p}"] =norm_adx
                    #print(f'features[f"ADX_{p}"]  is {features[f"ADX_{p}"]}')

                    del ADX_ALL


            #KDJ
            for p in self.indicator_params['KDJ']['apply_to']:
                if len(self.history[p]) >= 21:
                    high = np.array([k['high'] for k in self.history[p][-20:]], dtype=np.float64)
                    low = np.array([k['low'] for k in self.history[p][-20:]], dtype=np.float64)
                    close = np.array([k['close'] for k in self.history[p][-20:]], dtype=np.float64)
                    if self.gas < 2:
                        Close = close
                        Low = low
                        High = high
                    else:
                        Close = talib.EMA(close, timeperiod=self.gas)
                        Low = talib.EMA(low, timeperiod=self.gas)
                        High = talib.EMA(high, timeperiod=self.gas)
                    slowk,slowd =  talib.STOCH(
                            High,Low,Close,
                            fastk_period=9,
                            slowk_period=3, slowk_matype=0,
                            slowd_period=3, slowd_matype=0
                        )
                    kdj=3 *slowk - 2*slowd
                    kdj_v=kdj[-1]
                    features[f"KDJ_{p}"] =(kdj_v - 50) / 70

                    del slowk,slowd


                 
            for apply_to_period in self.indicator_params['EMA']['apply_to']:  # 遍历 5m/1h/4h
                for period in self.indicator_params['EMA']['periods']:
                    if len(self.history[apply_to_period]) >= period + 1:
                        close = np.array(
                            [k['close'] for k in self.history[apply_to_period][-period - 1:]],
                            dtype=np.float64
                        )

                        ema_raw=talib.EMA(close, timeperiod=period)
                        ema_value = ema_raw[-1]
                        key = f"EMA{period}_{apply_to_period}"

                        if period == 10:
                            value= (close[-1] - ema_value) / ema_value * 100
                            value=max(-4, min(4, value))

                            features[f'close_raw_ema{period}_distance_pct'] =value

                            value = ema_raw[-1]-ema_raw[-2]
                            value = max(-4, min(4, value))

                            #print(features['close_raw_ema5_distance_pct'][-1])
                            features[f'EMA{period}_slope']=value
                            #print(features['EMA_slope'][-1])

                        # if key=="EMA10_4h":
                        #    print(ema_value)
                        self.ema_normalizers[key].update(ema_value)
                        norm_value = self.ema_normalizers[key].normalize(ema_value)
                        norm_value=max(-4, min(4, norm_value))

                        if norm_value is not None:
                            features[key] = round(norm_value, 8)
                        else:
                            features[key] = 0.0  # 默认值

                        del ema_raw

            #交叉指标
            if "WILLR_15m" in features and "RSI_15m" in features:
                #print(f'hrer dzo')
                features['CROSS_RSI_WILL_15m']=(features['WILLR_15m']+ features['RSI_15m'])/2

            # 位置编码
            # ts = processed['timestamp']
            # pe = self._position_encoding(ts)
            # features.update(pe)
            # features['timestamp']=int(pd.to_datetime(processed['timestamp']))

            def tensor_to_float(t):
                """将张量转换为Python float"""
                if isinstance(t, torch.Tensor):
                    ret = t.detach().cpu().numpy().item()  # 解除梯度→转CPU→转标量
                    del t  # 显式删除张量
                    return ret
                elif isinstance(t, np.ndarray):
                    ret=t.item()
                    del t
                    return ret
                return t

            try:
                #print(features)
                # 生成特征字典（标量版）
                scalar_features = {
                    key: round(tensor_to_float(value), 8)  # 保留4位小数
                    for key, value in features.items()
                }
                #print(f'filtered_dict is {scalar_features["CROSS_RSI_WILL_5m"]}')

                # 验证并返回
                scalar_features['timestamp'] = processed['timestamp']
                # print(scalar_features['timestamp'])
                scalar_features['asset'] = 0


                ret = scalar_features
                #objgraph.show_growth()  # 显示当前内存中对象的增长情况
                # print(scalar_features)
                if len(ret) != 34:
                    print(f'have none len is {len(ret)}'  )
                    #gc.collect()
                    return None
                else:
                    #ret=ret[Config.FEATURES]
                    filtered_dict = {key: ret[key] for key in Config.FEATURES if key in ret}
                    #print(f'filtered_dict is {filtered_dict["CROSS_RSI_WILL_5m"]}')

                    #self.count+=1
                    #if self.count%10000==0:
                    #    gc.collect()

                    return filtered_dict

            except Exception as e:
                print(f"特征转换失败: {str(e)}")
                #gc.collect()
                return None

            return features
        except Exception as e:
            print(f"指标计算错误: {str(e)}")
            #gc.collect()
            return None

    def _aggregate_kline(self, period: str) -> Dict:
        """聚合K线数据"""
        window = list(self.buffers[period])
        ret ={
            'open': window[0]['open'],
            'high': max(k['high'] for k in window),
            'low': min(k['low'] for k in window),
            'close': window[-1]['close'],
            'volume': sum(k['volume'] for k in window),
            'timestamp': window[-1]['timestamp']
        }

        return ret

    def _position_encoding(self, timestamp: pd.Timestamp) -> Dict:
        # 基础时间分解
        minute_of_day = timestamp.hour * 60 + timestamp.minute
        day_of_week = timestamp.dayofweek  # 0=Monday, 6=Sunday
        month = timestamp.month

        # 周期性编码
        pe = {
            # 分钟级（日内周期）
            'minute_sin': torch.sin(torch.tensor(minute_of_day / (1440 / (2 * np.pi)))),
            'minute_cos': torch.cos(torch.tensor(minute_of_day / (1440 / (2 * np.pi)))),
            # 小时级
            'hour_sin': torch.sin(torch.tensor(timestamp.hour / (24 / (2 * np.pi)))),
            'hour_cos': torch.cos(torch.tensor(timestamp.hour / (24 / (2 * np.pi)))),
            # 周级
            'week_sin': torch.sin(torch.tensor(day_of_week / (7 / (2 * np.pi)))),
            'week_cos': torch.cos(torch.tensor(day_of_week / (7 / (2 * np.pi)))),
            # 月级
            'month_sin': torch.sin(torch.tensor(month / (12 / (2 * np.pi)))),
            'month_cos': torch.cos(torch.tensor(month / (12 / (2 * np.pi)))),
        }


        return {k: v.to(self.device) for k, v in pe.items()}
    def _position_encoding1(self, timestamp: pd.Timestamp) -> Dict:
        """时间位置编码"""
        minutes = timestamp.hour * 60 + timestamp.minute
        pe = {
            'pe_sin': torch.sin(torch.tensor(minutes / (1440 / (2 * np.pi)))),
            'pe_cos': torch.cos(torch.tensor(minutes / (1440 / (2 * np.pi))))
        }
        return {k: v.to(self.device) for k, v in pe.items()}

    #def _validate(self, features: Dict) -> bool:
        """验证必要特征是否存在"""
    #    required = ['open_5m', 'close_5m', 'RSI_5m', 'MACD_1h']
    #    return all(k in features for k in required)

    def to_file(self, from_file,to_file,asset):

        print(f'dzl {from_file}')
        df = pd.read_csv(from_file)

        if len(df)==0:


            return None
        buffer=[]
        #buffer = pd.DataFrame(columns=Config.FEATURES)
        #buffer=buffer[Config.FEATURES]
        count=0
        init=False


        #with tqdm(total=max_collect, desc=f"boss check work round {boss.round}") as pbar:

        for index, row in tqdm(df.iterrows(),total=len(df)):
            #print(row)

            re = self.process(row)


            #print(re)
            if re is not None:

                buffer.append(re)
                count+=1
                if count%10000==0:

                    df = pd.DataFrame(buffer)  # 直接转换字典列表
                    df["asset"] = asset
                    if init == False:
                        df.to_csv(to_file,index=False)
                        init=True

                    else:
                        df.to_csv(to_file,mode='a', header=False, index=False)
                        #init = True
                    del buffer
                    buffer = []




        #print(buffer)

        #df=pd.concat(buffer,ignore_index=True)
        df = pd.DataFrame(buffer)  # 直接转换字典列表


        #df["close_5m"]=df["close"]
        df["asset"]=asset
        if init == False:
            df.to_csv(to_file, index=False)
            init = True

        else:
            df.to_csv(to_file, mode='a', header=False, index=False)
            # init = True
        del buffer
        df=pd.read_csv(to_file)
        print(f'file is {to_file} len is {len(df)}')






import concurrent.futures
def process_task(dev, asset_item, file_type,id):
    try:
        processor = FeatureEngine(dev)
        from_file = f'source/{asset_item}_15m.csv'
        to_file = f'result/{asset_item}.csv'
        processor.to_file(from_file, to_file, id)
    except Exception as e:
        print(f"Error processing {asset_item} with id {id}: {e}")
        traceback.print_exc()  # 打印完整的错误堆栈
    #processor = FeatureEngine(dev)
    #from_file = f'source/{asset_item}_5m.csv'
    #to_file = f'result/{asset_item}.csv'
    #print(f'{ processor.to_file}')

    #processor.to_file(from_file, to_file,id)




# 使用示例
if __name__ == "__main__":
    mp.set_start_method('spawn', force=True)
    #data = np.array([1.8631, 1.8631, 1.8631, 1.8631, 0.0, 1.75672354, 1.57875772, 1.65023816])
    #print(data.nbytes)  # 打印内存占用
    ret = np.array([1.8631, 1.8631, 1.8631, 1.8631, 0.0,
                       0, 0, 1.75672354,
                       1.57875772, 1.65023816, 1.64039272, -0.49895624, 1.82787679,
                       2.00823539, -0.07970177, -0.82735918, -0.0803915, -0.39634088,
                       0.18307592, 0.0, -0.80112839, 1.85803764, -0.46954348, 0.06384651,
                       -0.58864853, float('nan'), 0.13499389, 0, 0, 0, 0])

    # 计算字典值占用的内存大小
    ret = np.array(list(ret), dtype=np.float32)
    print(f"Size of ret: {sys.getsizeof(ret)} bytes")

    # 如果需要查看字典中每个元素的大小
    total_size = sum(sys.getsizeof(item) for item in ret)

    print(f"Total size of all elements in ret: {total_size} bytes")
    for item in ret:
        print(f'sizie is {sys.getsizeof(item) }')

    #my_dict = {"key" + str(i): i for i in range(35)}

    # 查看字典对象的内存占用
    #print(asizeof.asizeof(my_dict))
    #processor = FeatureEngine()

    #from_file='ada_5m_new.csv'
    #to_file='ada_new.csv'
    #processor.to_file(from_file,to_file)

    #devid=[0,1,0,1,0,1]
    datalist=[]
    with open('data_list.json','r') as file:
        content = file.read()
        datalist=json.loads(content)
        #print(datalist)
    #asset=["btc","eth","ltc","doge","xrp","ada","pepe","sui","ton","trx","uni"]
    #asset = ["btc"]

    id=[ datalist.index(i) for i in datalist ]
    devid=[i%2 for i in id]
    type='all'

    #devid = [0]
    #asset = ["btc"]
    #id = [0]
    type = 'new'
    #process_task(0,datalist[0],type ,0)



    """
    for x in range(len(devid)):
        processor=FeatureEngine(devid[x])
        from_file=f'{asset[x]}_5m_{type}.csv'
        to_file=f'{asset[x]}_{type}.csv'
        processor.to_file(from_file, to_file)"""

    args = zip(devid, datalist, [type] * len(devid),id)

    # 使用进程池并行执行
    with concurrent.futures.ProcessPoolExecutor() as executor:
        executor.map(process_task, *zip(*args))








