import torch
import torch.nn as nn
from mamba_ssm import Mamba
class MambaBlock(nn.Module):
    def __init__(self, d_model, dropout=0.1, d_state=32, expand=2, dt_rank="auto"):
        super().__init__()
        self.norm = nn.LayerNorm(d_model)
        self.mamba = Mamba(
            d_model=d_model,
            d_state=d_state,  # SSM状态维度
            expand=expand,  # 隐藏层扩展因子
            dt_rank=dt_rank,  # 时间步长投影秩
            # 可添加其他参数：conv_kernel, bias, use_fast_path等
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):  # (B, S, H)
        x_in = self.norm(x)
        y = self.mamba(x_in)


        return x + self.dropout(y)


class MambaFinancialFeatureExtractor(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, dropout=0.1):
        super().__init__()
        self.encoder = nn.Linear(input_dim, hidden_dim)
        self.mamba_layers = nn.Sequential(
            *[MambaBlock(hidden_dim, dropout=dropout) for _ in range(num_layers)]
        )
        self.score_layer = nn.Linear(hidden_dim, 1)  # 权重层

        # ✅ 特征整合输出
        self.project = nn.Linear(hidden_dim, hidden_dim)  # 可选映射层，用于策略头等

        self.relu = nn.ReLU()

    def forward(self, x):  # x: (B, S, N)
        x = self.encoder(x)  # (B, S, H)
        x = self.mamba_layers(x)  # (B, S, H)
        x = x[:, -1, :]  # ✅ 只取最后一帧 (B, H)
        x = self.project(x)  # (B, H)
        x = self.relu(x)  # (B, H)
        return x  # 用于后续策略头等
