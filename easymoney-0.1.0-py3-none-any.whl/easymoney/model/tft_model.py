import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
#from position_kernel import PositionEncoder
torch.autograd.set_detect_anomaly(True)
from easymoney.model.actor_head import policyhead
import numpy as np
import pandas as pd
from typing import Dict,Mapping
from easymoney.run.configs import Config
from easymoney.model.mamba import MambaFinancialFeatureExtractor
from collections import defaultdict





class EnhancedVariableSelector(nn.Module):
    def __init__(self, input_dim):
        super().__init__()
        # 门控权重生成
        self.gate = nn.Sequential(
            nn.Linear(input_dim, input_dim),
            nn.GLU(dim=-1),  # 门控线性单元增强非线性
            nn.Dropout(0.3),
            nn.Linear(input_dim // 2, input_dim)
        )

    def forward(self, x):
        weights = self.gate(x)
        return x * weights


class StaticDynamicFusion(nn.Module):
    def __init__(self, static_dim, dynamic_dim):
        super().__init__()
        self.gate = nn.Sequential(
            nn.Linear(static_dim + dynamic_dim, dynamic_dim),
            nn.Sigmoid()
        )
        self.transform = nn.Linear(static_dim + dynamic_dim, dynamic_dim)

    def forward(self, static, dynamic):
        # static: [batch, static_dim], dynamic: [batch, seq, dynamic_dim]
        #static_expanded = static.unsqueeze(1).expand(-1, dynamic.size(1), -1)
        #print(f'new static is {new_static.shape}')


        combined = torch.cat([static, dynamic], dim=-1)
        gate = self.gate(combined)
        transformed = self.transform(combined)
        return dynamic + gate * transformed  # 残差门控融合


class EasyMoneyModel(nn.Module):
    def __init__(self, input_dim, hidden_dim_market, hidden_dim_pos,num_heads, num_layers, dropout,maxlen,num_assets):
        super(EasyMoneyModel, self).__init__()

        self.need_frozen=False

        self.need_positon = False
        self.maxlen=maxlen

        self.debug=False
        self.get_contribu=False
        self.var_selector = EnhancedVariableSelector(input_dim)

        self.static_encoder = nn.Embedding(num_embeddings=num_assets, embedding_dim=16)

        self.fusion = StaticDynamicFusion(16, input_dim)


        self.posencoder=nn.Linear(4, hidden_dim_pos)

        self.market_encoder= MambaFinancialFeatureExtractor(
            input_dim=input_dim,
            hidden_dim=hidden_dim_market,
            num_layers=num_layers,

        )


        self.policy_head= policyhead(hidden_dim_market+hidden_dim_pos,dropout=dropout)

        self.frozen()




    def batch_forward(self,x):


        if self.get_contribu==True:
            market = x["market"].requires_grad_()
            position = x["position"].requires_grad_()
        else:
            market = x["market"]
            position = x["position"]



        asset=x["asset"]


        pos_x = position[:, 0].float()
        #print(f'pso begin foward is {pos_x}')
        profit = position[ :, 1] * 10
        dur=position[:, 2] /500
        pos_size=position[:, 3]/10







        pos_x_t = pos_x*0.1
        #print(pos_x.squeeze(-1))


        en_hangced_market = self.var_selector(market)  # [batch, seq, dynamic_dim]
        static = self.static_encoder(asset)  # [batch, 64]

        #print(f'statci shpae is {static.shape}')
        final_market = self.fusion(static, en_hangced_market)  # [batch, seq, dynamic_dim]



        market_x_t = self.market_encoder(final_market)




        pos_feat_org = torch.cat((pos_x_t.unsqueeze(-1), profit.unsqueeze(-1), dur.unsqueeze(-1),pos_size.unsqueeze(-1)), dim=-1)

        pos_feat = self.posencoder(pos_feat_org)



        combine = torch.cat([market_x_t,pos_feat], dim=-1)


        logit,value_head,volume_head = self.policy_head(combine)
        dir=None

        values=None
        if self.get_contribu == True:
            #market_x.sum().backward()
            is_empty = (pos_x == 0)
            is_hold = (pos_x == 1)

            # 定义每种状态下相关的动作头索引
            empty_list = [0, 2]
            hold_list = [1, 3,4]

            # 假设你分析的是最后一个样本（即 batch 中最后一个），取其 logit
            logit_last = logit[-1]  # [12]

            # 确保 position、market 设置为需要梯度
            position.requires_grad_(True)
            market.requires_grad_(True)

            # 保留梯度以便 backward 后查看
            logit.retain_grad()
            position.retain_grad()
            market.retain_grad()

            # 根据状态选择索引
            if is_empty[-1]:
                indices = empty_list
            elif is_hold[-1]:
                indices = hold_list

            else:
                indices = []

            # 计算选择的动作头的 logit 和
            if indices:
                selected_logits = torch.stack([logit_last[i] for i in indices])  # shape: [N]
                max_logit = selected_logits.max()
                max_logit.backward()  # 仅反向传播最大项

                position_contribution = position.grad * position
                market_contribution = market.grad * market
                market_contribution = market_contribution[:, -1, :].squeeze(1)  # [B, F]
            else:
                print("无有效动作头索引，未执行反向传播")

            #if is_long.any():
            #    if position_contribution[-1,4]>0.001:


            #        print(f"Position Contributions: {position_contribution} grad is {position.grad} pos is {position_new}")
            #print(f"Position Contributions: {position_contribution}")

            #if is_long.any() and position_contribution[-1,4]==0:
            #    print(f'hoding is 0  pos grad is {position.grad[-1,4]} grad is {position.grad} holding is {position[-1,4]} pos is {position}')

            if self.debug == True:
                #print(f'last grad is {position_x.grad[-1, :]}')
                #print(f'last values is {position_x[-1, :]}')
                print(f"Position Contributions: {position_contribution}")
                #print(f"Market Contributions: {market_contribution}")
            final_contribution = torch.cat((market_contribution, position_contribution), dim=1)

            #print(final_contribution)
            #print(logit)
            return logit, value_head,final_contribution,volume_head

        return logit, value_head ,volume_head

    def forward(self, x):
        #x = x.float()
        action_probs = []
        state_values = []
        contribu = []
        adj = []
        rawlogit = []
        batch_num = 0

        min_size = 800
        # if len(x)>1:
        # if len(x)!=1 :
        #    print(f'x size is {len(x)}')
        if len(x) <= min_size:
            if self.get_contribu == True:
                action_probs_all, state_values_all, contribu, adj_all = self.batch_forward(x)

                return action_probs_all, state_values_all, contribu, adj_all

            else:
                action_probs_all, state_values_all, rawlogit = self.batch_forward(x)

                return action_probs_all, state_values_all, rawlogit
        else:
            # batch_num = len(x)//min_size
            if len(x) % min_size != 0:
                batch_num = len(x) // min_size + 1
                # print(f'batch_num1 is {batch_num} lenx is {len(x)}')

            else:
                batch_num = len(x) // min_size
                # print(f'batch_num2 is {batch_num} lenx is {len(x)}')
            for i in range(batch_num):
                start = i * min_size
                if (i + 1) * min_size <= len(x):
                    end = (i + 1) * min_size
                else:

                    end = len(x)

                # print(f'end is {end}  start is {start}')
                batch_x = x[start:end]
                # print(f'shape is {batch_x.shape}')
                if self.get_contribu == False:
                    action_probs_1, state_values_1, raw = self.batch_forward(batch_x)
                    action_probs.append(action_probs_1)
                    state_values.append(state_values_1)
                    rawlogit.append(raw)
                else:
                    action_probs_1, state_values_1, contribu_1, raw = self.batch_forward(batch_x)
                    action_probs.append(action_probs_1)
                    state_values.append(state_values_1)
                    contribu.append(contribu_1)
                    rawlogit.append(raw)

            if self.get_contribu == False:
                action_probs = torch.cat(action_probs)
                state_values = torch.cat(state_values)
                raw = torch.cat(rawlogit)
                return action_probs, state_values, raw
            else:
                action_probs = torch.cat(action_probs)
                state_values = torch.cat(state_values)
                raw = torch.cat(rawlogit)
                # state_values = state_values.squeeze(1)
                contribu = torch.cat(contribu)
                return action_probs, state_values, contribu, raw

    def frozen(self):
        if Config.FREEZE_POLICY== True:


            self.policy_head._frozen()
            #self.need_frozen=True


    def merge_dict_list_correctly(self,dict_list,device):
        """
            将包含Numpy数组的字典列表合并为PyTorch张量字典
            Args:
                dict_list: 包含多个字典的列表，每个字典结构相同且值为Numpy数组
                dtype: 输出张量的数据类型，默认为float32
            Returns:
                merged_dict: 合并后的字典，值为PyTorch张量
            """
        #device=self.device
        # 检查输入有效性
        if not isinstance(dict_list, (list, tuple)) or len(dict_list) == 0:
            raise ValueError("输入必须是非空列表或元组")

        if not all(isinstance(d, Mapping) for d in dict_list):
            raise TypeError("列表元素必须都是字典")

        # 获取基准键集合
        base_keys = set(dict_list[0].keys())
        if len(base_keys) == 0:
            raise ValueError("字典不能为空")

        # 验证所有字典结构一致性
        for i, d in enumerate(dict_list):
            current_keys = set(d.keys())
            if current_keys != base_keys:
                missing = base_keys - current_keys
                extra = current_keys - base_keys
                raise KeyError(
                    f"字典{i}键不匹配\n"
                    f"缺失键: {missing}\n"
                    f"多余键: {extra}"
                )

        # 预分配内存合并
        merged_dict = {}
        for key in base_keys:
            # 获取第一个样本的形状模板 (1, ...)
            sample_shape = dict_list[0][key].shape
            if len(sample_shape) < 1:
                raise ValueError(f"键'{key}'的数组维度不足")

            # 验证所有样本的形状兼容性
            expected_shape = sample_shape[1:]  # 除batch外的维度
            total_samples = 0
            for i, d in enumerate(dict_list):
                arr = d[key]
                if not isinstance(arr, np.ndarray):
                    raise TypeError(f"字典{i}的键'{key}'不是Numpy数组")

                if arr.shape[1:] != expected_shape:
                    raise ValueError(
                        f"字典{i}的键'{key}'形状异常\n"
                        f"预期: (N, {', '.join(map(str, expected_shape))})\n"
                        f"实际: {arr.shape}"
                    )
                total_samples += arr.shape[0]

            # 预分配Numpy数组
            merged_numpy = np.empty(
                (total_samples, *expected_shape),
                dtype=dict_list[0][key].dtype
            )

            # 填充数据
            ptr = 0
            for d in dict_list:
                arr = d[key]
                batch_size = arr.shape[0]
                merged_numpy[ptr:ptr + batch_size] = arr
                ptr += batch_size

            # 转换为张量并转换数据类型
            merged_dict[key] = torch.from_numpy(merged_numpy).to(device)
            #print(merged_dict[key].shape)

        return merged_dict

    def create_input_dict(self,raw_sample, device) -> Dict[str, torch.Tensor]:
        # print(self.xreal_list)
        # 检查样本长度
        # print(f'len fo raw is {len(raw_sample)}')
        #print(raw_sample)

        raw_data= raw_sample['data']
        state=raw_sample['state']

        maxlen=self.maxlen
        assert len(raw_data) == maxlen, f"输入必须包含{maxlen}个时间步 now is {len(raw_data)}"

        #step=2
        raw_sample = np.array(raw_data, dtype=np.float32)  #
        #print(f'raw last is {raw_sample[-1, :]}')
        #raw_sample = raw_sample[1:len(raw_sample)+1:step]


        #print(f'new last is {raw_sample[-1,:]}')
        #arr_raw = raw_sample[:, :-5]
        arr_raw = raw_sample[:, 1:]
        pos=[state["pos"],state["profit"],state["dur"],state["position_size"]]
        #print(pos)



        encoder_cont = torch.from_numpy(arr_raw[:, :]).float()  # 显式转为float32



        position  = torch.tensor(pos, dtype=torch.float32)  # 或 int64 根据需要选择类型
        asset = torch.from_numpy(raw_sample[:, 0]).long()
        #print(encoder_cont.shape)

        model_input = {
            "asset": asset.unsqueeze(0).to(device),
            "market": encoder_cont.unsqueeze(0).to(device),
            "position": position.unsqueeze(0).to(device),

        }



        return model_input






# 你可以在训练过程中定期调用这个函数
#print_gpu_memory()  # 监控当前显存使用情况

if __name__ == "__main__":

    """
    # 测试模型
    batch_size = 32
    seq_len = 10
    dim = 64
    action_dim = 4
    hidden_dim = 128
    num_heads = 4
    num_layers = 2

    model = SimpleTransformerAgent(input_dim=dim, hidden_dim=hidden_dim,
                                   num_heads=num_heads, num_layers=num_layers,
                                   action_dim=action_dim)

    optimizer = optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.MSELoss()

    # 随机输入 (batch_size, seq_len, dim)
    input_tensor = torch.randn(batch_size, seq_len, dim)
    target = torch.randn(batch_size, action_dim)  # 假设目标是与动作相关的某个张量


    # 得到策略和价值输出
    action_probs, state_values = model(input_tensor)

    target_values = torch.randn(batch_size, 1)  # 假设目标值是随机生成的

    value_loss = criterion(state_values.squeeze(), target_values)

    loss = criterion(action_probs, target)+value_loss


    #print("Action probabilities:", action_probs.shape)  # 应该是 (batch_size, action_dim)
    #print("State values:", state_values.shape)  # 应该是 (batch_size, 1)

    optimizer.zero_grad()  # 清除之前的梯度
    loss.backward()  # 计算梯度
    # 检查梯度是否存在

    for name, param in model.named_parameters():
        print(f"{name} requires_grad: {param.requires_grad}")
        if param.grad is not None:
            print(f"Gradient for {name}: {param.grad.abs().mean():.4e}")
        else:
            print(f"Gradient for {name} is None")


    # 进行一次优化步骤
    optimizer.step()
    """
    asset_df = pd.read_csv('btc_new.csv')
    asset_df = asset_df[Config.FEATURES]
    print(f'df len is {len(asset_df.columns)}')
    asset_df = asset_df.iloc[:, 5:]
    print(f'afiter df len is {len(asset_df.columns)}')
    # asset_df = asset_df.iloc[:, :-5]
    asset_df = asset_df.iloc[-129:]  # 使用最后 120 行
    dd = asset_df.values
    len_input=len(dd)
    model = EasyMoneyModel(
        input_dim=50,
        hidden_dim_market=512,
        hidden_dim_pos=32,
        num_heads=8,
        num_layers=4,
        dropout=0.1,
        maxlen=len(dd),
        num_assets=6
    ).to("cuda:0")
    ret=model.create_input_dict(dd)
    print(f'market shape is {ret["market"].shape}')
    print(f'position shape is {ret["position"].shape}')
    print(f'asset shape is {ret["asset"].shape}')
    ret_data = {key: value.clone().cpu().numpy() for key, value in ret.items()}


    list_input=[]
    for x in range(500):
        list_input.append(ret_data)

    list_in=model.merge_dict_list_correctly(list_input)
    print(f'market shape is {list_in["market"].shape}')
    print(f'position shape is {list_in["position"].shape}')
    print(f'asset shape is {list_in["asset"].shape}')






    _,_,raw_logit=model(list_in)
    print(raw_logit.shape)

