import torch
import torch.nn as nn

import torch
import torch.nn as nn
import torch.nn.functional as F

class volumehead(nn.Module):
    def __init__(self, input_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(input_dim),
            nn.Linear(input_dim, input_dim),
            nn.Sigmoid(),
            nn.Linear(input_dim, 1)  # 输出策略 logits（非概率）
        )

    def forward(self, x):
        return self.net(x)

class StrategyHead(nn.Module):
    def __init__(self, input_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(input_dim),
            nn.Linear(input_dim, input_dim),
            nn.ReLU(),
            nn.Linear(input_dim, 1)  # 输出策略 logits（非概率）
        )

    def forward(self, x):
        return self.net(x)



class policyhead(nn.Module):
    def __init__(self, hidden_dim_total, dropout=0.1):
        super().__init__()
        self.shared_layer = nn.Sequential(
            nn.Linear(hidden_dim_total, hidden_dim_total * 2),
            nn.LayerNorm(hidden_dim_total * 2),
            nn.ReLU(),
            nn.Dropout(dropout)
        )

        self.vol_head = volumehead(hidden_dim_total * 2)


        self.value_head = nn.Linear(hidden_dim_total * 2, 1)

        self.empty_head = StrategyHead(hidden_dim_total * 2)  # 保持不持仓
        self.hold_head = StrategyHead(hidden_dim_total * 2)  # 保持持仓
        self.open_head = StrategyHead(hidden_dim_total * 2)  # 做多策略头
        self.more_head = StrategyHead(hidden_dim_total * 2)  # 加多策略头
        self.close_head = StrategyHead(hidden_dim_total * 2)  #平多策略头


    def _frozen(self):
        for param in self.shared_layer.parameters():
            param.requires_grad = False

            # 冻结策略 heads
        for head in [
            self.empty_head,
            self.hold_head,
            self.open_head,
            self.more_head,
            self.close_head,

            self.vol_head
        ]:
            for param in head.parameters():
                param.requires_grad = False

    def forward(self, x):
        # x: [B, D]
        x_shared = self.shared_layer(x)  # [B, D']
        #dir_raw = self.dir_head(x_shared)  # [B, 1]
        empty_head = self.empty_head(x_shared)
        hold_head = self.hold_head(x_shared)
        open_head = self.open_head(x_shared)
        more_head=self.more_head(x_shared)
        close_head = self.close_head(x_shared)
        vol_head=self.vol_head(x_shared)


        logits = torch.cat([empty_head, hold_head, open_head,more_head,
                            close_head], dim=-1)

        value_score = self.value_head(x_shared)  # [B, 1]

        return logits, value_score,vol_head
