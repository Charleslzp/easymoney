"""
Selective Scan Interface - CPU 版本（完全修复）
兼容 NumPy 2.0，纯 PyTorch 实现
"""
import torch
import torch.nn.functional as F
from einops import rearrange, repeat
import os

os.environ['CUDA_VISIBLE_DEVICES'] = ''

def selective_scan_fn(
    u, delta, A, B, C, D=None, z=None, delta_bias=None, 
    delta_softplus=False, return_last_state=False
):
    """CPU 实现的 selective scan"""
    device = torch.device('cpu')
    dtype = u.dtype
    
    u = u.to(device).contiguous()
    delta = delta.to(device).contiguous()
    A = A.to(device).contiguous()
    B = B.to(device).contiguous()
    C = C.to(device).contiguous()
    if D is not None:
        D = D.to(device).contiguous()
    if z is not None:
        z = z.to(device).contiguous()
    
    batch, dim, seqlen = u.shape
    d_state = A.shape[1]
    
    if delta_bias is not None:
        delta = delta + delta_bias.view(1, -1, 1)
    
    if delta_softplus:
        delta = F.softplus(delta)
    
    if B.dim() == 2:
        B = B.unsqueeze(0).expand(batch, -1, seqlen)
    if C.dim() == 2:
        C = C.unsqueeze(0).expand(batch, -1, seqlen)
    
    h = torch.zeros(batch, dim, d_state, device=device, dtype=dtype)
    outputs = []
    
    for t in range(seqlen):
        u_t = u[:, :, t]
        delta_t = delta[:, :, t]
        B_t = B[:, :, t]
        C_t = C[:, :, t]
        
        dA = torch.exp(A.unsqueeze(0) * delta_t.unsqueeze(-1))
        dB = B_t.unsqueeze(1) * delta_t.unsqueeze(-1)
        
        h = h * dA + u_t.unsqueeze(-1) * dB
        y = (h * C_t.unsqueeze(1)).sum(dim=-1)
        
        if D is not None:
            y = y + u_t * D.unsqueeze(0)
        
        outputs.append(y)
    
    out = torch.stack(outputs, dim=2)
    
    if z is not None:
        out = out * F.silu(z)
    
    if return_last_state:
        return out, h
    return out


def mamba_inner_fn(
    xz, conv1d_weight, conv1d_bias, x_proj_weight, delta_proj_weight,
    out_proj_weight, out_proj_bias, A, B=None, C=None, D=None, 
    delta_bias=None, B_proj_bias=None, C_proj_bias=None, 
    delta_softplus=True, checkpoint_lvl=0
):
    """Mamba 内部函数 - CPU 实现"""
    batch, seqlen, d_inner_2 = xz.shape
    d_inner = d_inner_2 // 2
    
    x, z = xz.chunk(2, dim=-1)
    x = rearrange(x, 'b l d -> b d l')
    
    # 处理 conv1d_weight 维度
    if conv1d_weight.dim() == 2:
        conv_weight = conv1d_weight.unsqueeze(1)
    elif conv1d_weight.dim() == 3:
        if conv1d_weight.shape[1] != 1:
            conv_weight = conv1d_weight.view(d_inner, 1, -1)
        else:
            conv_weight = conv1d_weight
    elif conv1d_weight.dim() == 4:
        conv_weight = conv1d_weight.squeeze(2)
    else:
        raise ValueError(f"Unexpected conv weight shape: {conv1d_weight.shape}")
    
    kernel_size = conv_weight.shape[2]
    x_padded = F.pad(x, (kernel_size - 1, 0))
    x = F.conv1d(x_padded, conv_weight, conv1d_bias, groups=d_inner)
    x = x[..., :seqlen]
    x = rearrange(x, 'b d l -> b l d')
    
    x = F.silu(x)
    
    x_dbl = F.linear(x, x_proj_weight)
    dt_rank = delta_proj_weight.shape[1]
    d_state = A.shape[1]
    delta, B, C = torch.split(x_dbl, [dt_rank, d_state, d_state], dim=-1)
    delta = F.linear(delta, delta_proj_weight)
    
    u = rearrange(x, 'b l d -> b d l')
    delta = rearrange(delta, 'b l d -> b d l')
    B = rearrange(B, 'b l n -> b n l')
    C = rearrange(C, 'b l n -> b n l')
    z_t = rearrange(z, 'b l d -> b d l')
    
    y = selective_scan_fn(
        u, delta, A, B, C, D=D, z=z_t,
        delta_bias=delta_bias, delta_softplus=delta_softplus
    )
    
    y = rearrange(y, 'b d l -> b l d')
    out = F.linear(y, out_proj_weight, out_proj_bias)
    
    return out


mamba_inner_ref = mamba_inner_fn

def mamba_chunk_scan_combined(*args, **kwargs):
    raise NotImplementedError("CUDA not available")

def mamba_split_conv1d_scan_combined(*args, **kwargs):
    raise NotImplementedError("CUDA not available")
